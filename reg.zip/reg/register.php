<?php include('server.php') ?>
<!DOCTYPE html>
<html lang="en">
<!-- Basic -->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Site Metas -->
    <title>Freshshop - Ecommerce Bootstrap 4 HTML Template</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Site Icons -->
    <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
    <link rel="apple-touch-icon" href="images/apple-touch-icon.png">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Site CSS -->
    <link rel="stylesheet" href="css/style.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/custom.css">
	    <link rel="stylesheet" href="sign.css">


    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Amiri:ital@1&display=swap" rel="stylesheet">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Amiri:ital@1&family=Lemonada:wght@300&display=swap" rel="stylesheet">
</head>

<body>


<div class="signup__container">
  <div class="container__child signup__thumbnail">
    <div class="thumbnail__logo">
      
    </div>
    <div class="thumbnail__content text-center">
      <h1 class="heading--primary">اهلا بك الى مذاق</h1> <br>
      <h2 class="heading--secondary">موقع يشمل كل الوصفات والاطباق من انحاء العالم باللغة العربية</h2>
    </div>
    <div class="thumbnail__links">
      <ul class="list-inline m-b-0 text-center">
       
        <li><a href="https://www.behance.net/alexdevero" target="_blank"><fa class="fa fa-behance"></fa></a></li>
        <li><a href="https://github.com/alexdevero" target="_blank"><i class="fa fa-github"></i></a></li>
        <li><a href="https://twitter.com/alexdevero" target="_blank"><i class="fa fa-twitter"></i></a></li>
      </ul>
    </div>
    <div class="signup__overlay"></div>
  </div>
  <div class="container__child signup__form">
     <form method="post" action="regiser.php">
  	<?php include('errors.php'); ?>
      <div class="form-group">
        <label for="username">اسم المستخدم</label>
        <input class="form-control" name="username" value="<?php echo $username; ?>">
      </div>
      <div class="form-group">
        <label for="email">الايميل</label>
        <input class="form-control" type="email" name="email" value="<?php echo $email; ?>">
      </div>
      <div class="form-group">
        <label for="password">كلمة السر</label>
        <input class="form-control" type="password" name="password_1">
      </div>
      <div class="form-group">
        <label for="passwordRepeat">تاكيد كلمة السر</label>
        <input class="form-control"  type="password" name="password_2">
      </div>
      <div class="m-t-lg">
        <ul class="list-inline">
          <li>
            <button class="btn btn--form"  type="submit" class="btn" name="reg_user">تسجيل</button> 
          </li>
          <li>
		  <p>
		   لديك حساب؟ <a a class="signup__link" href="form1.html">سجل الان</a>
            
			</p>
          </li>
        </ul>
      </div>
    </form>  
  </div>
</div>

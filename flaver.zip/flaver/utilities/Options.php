
<?php
class OptionsClass
{
    public static $Area = "";
    public static $Component = "";
    public static $Action  = "";
    public static $ComponentData = [];
    public static $Path = "/flaver/";


    public static $UploadFloder = "/flaver/uploads/";




    public static $Url = [];
    public static $Lang = [
        "add" => "إضافة", "index" => "الرئيسية", "send" => "إرسال", "edit" => "تعديل", "delete" => "حذف", "reset" => "مسح",
        "deleted_msg" => "  تم الحذف بنجاح",
        "added_msg" => "  تم الحفظ بنجاح ",
        "comment_msg" => "  تم  إضافة التعليق بنجاح شكرا ",
        "user_add_msg" => "  تسجيل حساب جديد يمكتك الان تسجيل الدخول ٫",
        "logout_msg" => " تم تسجيل الخروج بنجاح   ",
        "updated_msg" => "  تم التحديث بنجاح",
        "login_error_msg" => "البريد الاكترونى او البريد الاكترونى خطأ الرجاء اغداة المحاولة",
        "login_msg" => " مرحبا تم الدخول بنجاح",

        "nodata_msg" => "    لا يوجد اى بيانات",



        "cart_empty_msg" => "لا يوجد اى منتجات فى السلة   ",

        "male" => ["breakfast" => "فطور", "lunch" => "غداء", "dinner" => "عشاء", "Sweetening" => "تحلية", "Sidedishes" => "اطباق جانبية"],

        "time" => [
            "10" => "اقل من 10 دقائق", "20" => "اقل من 20 دقيقة", "30" => "اقل من 30 دقيقة", "40" => "اقل من40 دقيقة", "50" => " 50 دقيقة فاكثر"
        ],
        "difficulty" => ["easy" => "سهل", "mid" => "متوسط", "hard" => "صعب"]

     

    ];




    public static function getValue($name)
    {
        $r = "";
        if (OptionsClass::$Action  == "edit") {
            $r = OptionsClass::$ComponentData[$name];
        }
        return $r;
    }





    public static function getDate()
    {
        return date('Y-m-d H:i:s');
    }
    public static function viewDate($date)
    {
        return date('l \t\h\e jS', strtotime($date));
    }
}
?>
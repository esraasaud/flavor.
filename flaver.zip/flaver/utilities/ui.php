<?php

class MessageClass
{

  static  function recipeItBlock($v)
    {

?>
        <div class="col-md-6 col-lg-4 col-xl-4">
            <div class="blog-box">


                <div class="blog-img">
                    <img src="<?= OptionsClass::$UploadFloder . $v["image"] ?>" class="img-fluid" alt="Image">
                </div>



                <div class="blog-content">
                    <div class="title-blog">
                        <?php UsersComponent::getUserBlock($v["user"]); ?>

                        <br />
                        <h3> <?= $v["name"] ?> </h3>
                        <p><?= $v["des"] ?></p>
                    </div>



                </div>
                <ul class="option-blog">

                <li><a class="<?= RecipeComponent::_is_liked($v["id"]) ?  "act" : ""  ?>" href="#" onclick="_setlike(event,this)" data-url="<?= OptionsClass::$Path ?>Recipe/cart/<?= $v["id"] ?>"><i class="bi bi-list"></i></a></li>
                    <li><a class="<?= RecipeComponent::_is_liked($v["id"]) ?  "act" : ""  ?>" href="#" onclick="_setlike(event,this)" data-url="<?= OptionsClass::$Path ?>Recipe/like/<?= $v["id"] ?>"><i class="bi bi-heart"></i></a></li>
                    <li> <a class="<?= RecipeComponent::_is_bookmart($v["id"]) ?  "act" : ""  ?>" href="#" onclick="_setbookmark(event,this)" data-url="<?= OptionsClass::$Path ?>Recipe/bookmarke/<?= $v["id"] ?>"> <i class="bi bi-bookmark"></i></a></li>
                    <li><a href="<?= OptionsClass::$Path ?>Recipe/item/<?= $v["id"] ?>"><i class="bi bi-eye"></i></a></li>
                </ul>

            </div>
        </div>



<?php

    }
} ?>
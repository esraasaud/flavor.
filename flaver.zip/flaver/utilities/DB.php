
<?php


class DBClass
{
    var  $servername = "localhost";
    var $username = "root";
    var  $password = '';
    var  $dbname = "flaver";

    function connect()
    {
        try {
            $conn = new PDO("mysql:host=$this->servername;dbname=$this->dbname", $this->username, $this->password);
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            // echo "Connected successfully";
        } catch (PDOException $e) {

            echo  MessageClass::error("" . $e->getMessage());
        }
        return $conn;
    }

    public function select($sql)
    {
        try {

        $conn = $this->connect();
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll(\PDO::FETCH_ASSOC);
        $conn = null;
    } catch (PDOException $e) {

        echo  MessageClass::error("" . $e->getMessage());
    }
        return $result;
    }


    public function query($sql)
    {
        try {
            $conn = $this->connect();
            $stmt = $conn->prepare($sql);
            $result =  $stmt->execute();
            $conn = null;
            return  $result;
        } catch (PDOException $e) {

            echo  MessageClass::error("" . $e->getMessage());
        }
    }

    public function getData(string $table = "", string $custome = "*", string $where = "")
    {

        $where =  $where != "" ? "where   $where" : "";
        $sql = "select $custome from `$table`  $where";

        $result = $this->select($sql);
        return $result;
    }

    public function insert(string $table = "", $data = [])
    {
        $values = "";
        $names = "";
        $sp = "";

        foreach ($data as $k => $v) {
            $values .= $sp . "'$v'";
            $names .= $sp . $k;
            $sp = ",";
        }
        $sql = "INSERT INTO   $table  ($names) values ($values)";
        $result = $this->query($sql);


        return $result;
    }


    public function update(string $table = "", $data = [], $where = "")
    {
        $values = "";
        $sp = "";
        foreach ($data as $k => $v) {
            $values .= " $sp `$k`='$v' ";
            $sp=",";
        }
        $where =  $where != "" ? "where   $where" : "";
        $sql = "UPDATE    $table  SET $values  $where ";
        $result = $this->query($sql);
        return $result;
    }

    public function delete(string $table = "",  $where = "")
    {
       
        $where =  $where != "" ? "where   $where" : "";
        $sql = "DELETE FROM  $table  $where ";
        $result = $this->query($sql);
        return $result;
    }


}



?>

<?php

class MessageClass
{

    public static function msg(string $content ,string $class="alert-info",String $icon='bi-info-circle',bool $closeBtn= false)
    {
        $r= '<div class="alert '.$class.'" role="alert"><i class="bi '.$icon.'"></i>' ." ".$content;
        if ($closeBtn){
        $r.=' <button type="button" class="btn-close" data-bs-dismiss="alert" style="    FLOAT: LEFT;" aria-label="Close"></button>';
        }
        $r.='</div>';
        return $r; 
    }


    public static function  warning(string $s)
    {
        
    return self::msg($s ,"alert-warning");

    }
    public static function  error(string $s)
    {
        return  self::msg($s ,"alert-danger",'bi-x');
    }

    public static function  success(string $s ,bool $closeBtn= false)
    {
        return    self::msg($s ,"alert-success" ,'bi-check' ,$closeBtn);

    }

    public static function  info(string $s)
    {
        return   self::msg($s);

    }

    public static function  light(string $s)
    {
        return   self::msg($s ,"light","");

    }

    public static function  dark(string $s)
    {
        return   self::msg($s ,"dark","");

    }

}


<?php



class PageClass
{


    public static function  url()
    {

        if (isset($_SERVER['PATH_INFO'])) {
            $path = $_SERVER['PATH_INFO'];
            $path_split = explode('/', ltrim($path));
            return  array_values(array_filter($path_split));
        } else {
            return  '/';
        }
    }




    public static function  updateUrl()
    {

        $m_index = 1;
        $c_index = 0;
        $s_index = 2;

        $path_split = PageClass::url();
        $area = "";


        if (OptionsClass::$Area != "") {
            $m_index = 2;
            $c_index = 1;
            $area = OptionsClass::$Area . "/";
            $s_index = 3;

        }


        if ($path_split != "/") {
            $req_controller = isset($path_split[$c_index]) ? $path_split[$c_index] : 'index';
            $req_method = isset($path_split[$m_index]) ? $path_split[$m_index] : 'index';
            OptionsClass::$Component =   $req_controller;
            OptionsClass::$Action =   $req_method;

            OptionsClass::$Url["param"] = array_slice($path_split, $s_index);
            OptionsClass::$Url["index"] = OptionsClass::$Path . "$area";


            OptionsClass::$Url["component"] = OptionsClass::$Url["index"] . OptionsClass::$Component;
            OptionsClass::$Url["add"] = OptionsClass::$Url["component"] . "/add/";
            OptionsClass::$Url["edit"] = OptionsClass::$Url["component"] . "/edit/";
            OptionsClass::$Url["delete"] = OptionsClass::$Url["component"] . "/delete/";
        } else {
            OptionsClass::$Component =   "index";
            OptionsClass::$Action =   "index";
        }

    }



    public static function  main()
    {


        $req_method = OptionsClass::$Action;
        $c_name = ucfirst(OptionsClass::$Component) . "Component";


        $area = OptionsClass::$Area != "" ? OptionsClass::$Area . "/" : "";
        $req_controller_exists = dirname(__DIR__) . '/Components/' . $area . $c_name  . '.php';


        if (file_exists($req_controller_exists)) {
            require_once   $req_controller_exists;
            $controller = $c_name;
            $ControllerObj = new $controller();
            OptionsClass::$Url["action"] = $req_method;



            if (method_exists($ControllerObj, $req_method)) {
               // if ($ControllerObj->$req_method() != null) {
                    return $ControllerObj->$req_method();
                //}
            } else {
                OptionsClass::$Url["action"] = "index";
                return $ControllerObj->index();
            }
        } else {




            header('HTTP/1.1 404 Not Found');
            return  MessageClass::error("404 - The file - <strong>  $area  $c_name </strong> - not found");
            die();
        }
    }


    public static function   module($name, $options = null, $req_method = "")
    {
        $m_name = ucfirst($name) . 'Module';
        $req_m_exists = dirname(__DIR__) . '/Modules/' . $m_name  . '.php';
        if (file_exists($req_m_exists)) {
            require_once   $req_m_exists;
            $mObj = new $m_name($options);

            if ($req_method != '') {
                return   $mObj->$method();
            } else {
                return   $mObj->index();
            }
        } else {
            return MessageClass::warning("! File Not Found '{$req_m_exists}'");
        }
    }




    public static function view($name)
    {
        $m_name = ucfirst($name) . 'View';
        $area = OptionsClass::$Area != "" ? OptionsClass::$Area . "/" : "";
        $req_m_exists = dirname(__DIR__) . '/Views/' . $area . $m_name  . '.php';
        if (file_exists($req_m_exists)) {
            require_once  $req_m_exists;
        } else {
            return MessageClass::warning("! File Not Found '{$req_m_exists}'");
        }
    }


    public static function  uplaodFiles()
    {

        $target_dir = dirname(__DIR__) . "/uploads/";

        foreach ($_FILES as $k => $file) {
            $imageFileType = strtolower(pathinfo(basename($file["name"]), PATHINFO_EXTENSION));
            $newfilename = uniqid() . "." . $imageFileType;
            $_POST[$k] = $newfilename;
            $target_file = $target_dir . $newfilename;
            if (move_uploaded_file($file["tmp_name"], $target_file)) {
            } else {
                unset($_POST[$k]);
            }
        }
    }
    public static function  redirect($url, $msg = "")
    {

        $url .= ($msg == "") ? "" : '?msg=' . $msg;
        echo '  <meta http-equiv="refresh" content="0; URL=' . $url . '" />';
    }
}



?>



<?php

/** Autoloading The required Classes **/

class CartComponent
{

    function __construct()
    {
    }

    public function index()
    {
        global $db;
        if (isset($_SESSION["login"])) {
        $table = "bookmarkes";
        $type = "recipe_cart";
        $w =  "obj_type='$type' and  user='{$_SESSION["login"]["id"]}'";

        $data = $db->getData($table, "*", $w);

        foreach ($data  as $d) {

            OptionsClass::$ComponentData["data"][] = $db->getData("recipes", "*", "id='{$d['obj_id']}'")[0];
        }

        OptionsClass::$ComponentData["type"] = "recipe";

        return PageClass::view("cart");
    } else {

        return PageClass::view("login");
    }


    }


    public function item()
    {

        global $db;

        $id = OptionsClass::$Url["param"][0];

        $data = $db->getData("recipes", "*", "id ='$id'");
        OptionsClass::$ComponentData["data"] = $data[0];
        return PageClass::view("cart");
    }



    static function _is_chek($id ,$type)
    {
        global $db;
        if (isset($_SESSION["login"]["id"])) {
            $table = "cartcheck";
            $w =  " obj_type='$type' and  obj_id='$id' and  user='{$_SESSION["login"]["id"]}'";

            $data = $db->getData($table, "*", $w);
            return (count($data) > 0);
        }
        return false;
    }



    public function check()
    {
        global $db;

        if (isset($_SESSION["login"]["id"])) {
            $id = OptionsClass::$Url["param"][0];
            $table = "cartcheck";
            $type= OptionsClass::$Url["param"][1];

            $w =  " obj_type='$type' and  obj_id='$id' and  user='{$_SESSION["login"]["id"]}'";
            $data = $db->getData($table, "*", $w);
            $a = "";
            if (count($data) <= 0) {
                $data = [
                    "user" => $_SESSION["login"]["id"],
                    "obj_type" => $type,
                    "obj_id" => $id
                ];

                if ($db->insert($table, $data)) {
                    $a = "insert";
                }
            } else {
                $db->delete($table, $w);
                $a = "remove";
            }
        }

        return $a;
    }

    


}
?>

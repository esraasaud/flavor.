
<?php

class ProductsComponent
{

    function __construct()
    {
    }


    public function item()
    {

        global $db;

        $id = OptionsClass::$Url["param"][0] ;

        $data = $db->getData("products", "*", "id ='$id'");

        OptionsClass::$ComponentData["data"] = $data[0];

        OptionsClass::$ComponentData["related"] = $db->getData("products", "*", " id<>$id   ORDER BY RAND()  limit 0,3");
        OptionsClass::$ComponentData["products_categories"] =   $db->getData("products_categories");

        return PageClass::view("ProductsItem");
    }



    public function index()
    {


        global $db;

    
        $filter = [];
        $w = "";

        if (isset($_GET["filter"])){
        $filtertmp= explode( ";" ,$_GET["filter"]);
        $sp="  ";

        foreach ($filtertmp as $f) {

           $ftmp= explode( "," ,$f);
           if (count($ftmp)  >1){
           $filter [$ftmp[0]]=$ftmp[1];

           $w .="$sp `{$ftmp[0]}`='{$ftmp[1]}' ";

           $sp =" and ";
        }
        }}
        OptionsClass::$ComponentData["filter"] =$filter;

  

        $w =$w==""? "1=1":$w;
        OptionsClass::$ComponentData["data"] = $db->getData("products","*",$w);
        OptionsClass::$ComponentData["products_categories"] =   $db->getData("products_categories");

        return PageClass::view("products");
    }

    public function add()
    {
        global $db;
        if (isset($_POST["name"])) {
            PageClass::uplaodFiles();
            if ($db->insert("products", $_POST)) {

                $_GET["msg"] = "added";
            }
        }
        OptionsClass::$ComponentData["products_categories"] =   $db->getData("products_categories");

        return PageClass::view("Addproducts");
    }




    public function like()
    {
        global $db;
        $id = OptionsClass::$Url["param"][0];
        $table = "likes";
        $type = "product";
        $w =  " obj_type='$type' and  obj_id='$id' and  user='{$_SESSION["login"]["id"]}'";

        $data = $db->getData($table, "*", $w);
        $a = "";
        if (count($data) <= 0) {
            $data = [
                "user" => $_SESSION["login"]["id"],
                "obj_type" => "$type ",
                "obj_id" => $id
            ];

            if ($db->insert($table, $data)) {
                $a = "insert";
            }
        } else {
            $db->delete($table, $w);
            $a = "remove";
        }
        return $a;
    }

    public function bookmarke()
    {
        global $db;


        $id = OptionsClass::$Url["param"][0];
        $table = "bookmarkes";
        $type = "product";
        $w =  " obj_type='$type' and  obj_id='$id' and  user='{$_SESSION["login"]["id"]}'";

        $data = $db->getData($table, "*", $w);
        $a = "";
        if (count($data) <= 0) {
            $data = [
                "user" => $_SESSION["login"]["id"],
                "obj_type" => $type,
                "obj_id" => $id
            ];

            if ($db->insert($table, $data)) {
                $a = "insert";
            }
        } else {
            $db->delete($table, $w);
            $a = "remove";
        }
        return $a;
    }



    static function _is_liked($id)
    {
       global $db;
       $table = "likes";
       $type = "product";
       $w =  " obj_type='$type' and  obj_id='$id' and  user='{$_SESSION["login"]["id"]}'";
       $data = $db->getData($table, "*", $w);
       return (count($data) > 0);
    }
    static  function _is_bookmart($id)
    {
       global $db;
       $table = "bookmarkes";
       $type = "product";
       $w =  " obj_type='$type' and  obj_id='$id' and  user='{$_SESSION["login"]["id"]}'";
       $data = $db->getData($table, "*", $w);
       return (count($data) > 0);

    }
}
?>


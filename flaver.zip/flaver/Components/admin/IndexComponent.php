
<?php

/** Autoloading The required Classes **/

class indexComponent
{

    function __construct()
    {
    }

    public function index()
    {


        global $db;


        if (isset($_SESSION["login"]) &&trim($_SESSION["login"]["type"])  == "admin") {

            return "";
        } else {

            if (isset($_POST["email"])) {
                $v = $db->getData("users", "*", "email = '{$_POST["email"]}' and password = '{$_POST["password"]}'")[0];


   

                if ($v != null) {
                    $_SESSION["login"] =  $v;
                    PageClass::redirect(OptionsClass::$Url["admin"], "login");
                } else {
                    var_dump($v);

                    $_GET["msg"] = "login_error";
                }
            }
        }
    }

    public function login()
    {

        echo "Login Method";
    }

    public function showUsers()
    {
    }
}
?>

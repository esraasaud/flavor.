
<?php

class SlideshowComponent
{
    function __construct()
    {
    }

    public function index()
    {
        global $db;
        OptionsClass::$ComponentData = $db->getData("slideshow");
        return PageClass::view("slideshow");
    }






    public function add()
    {
        global $db;
        if (isset($_POST["name"])) {
            PageClass::uplaodFiles();
            $db->insert("slideshow", $_POST); 


            PageClass::redirect(OptionsClass::$Url["component"], "added");
            return ".....";
        }

       
        return PageClass::view("slideshow");
    }




    public function edit()
    {
        global $db;
        if (isset($_POST["name"])) {
            PageClass::uplaodFiles();
            $db->update("slideshow", $_POST, "id = '" . OptionsClass::$Url["param"][0] . "'");
            PageClass::redirect(OptionsClass::$Url["component"], "updated");
            return ".....";
        }
        OptionsClass::$ComponentData =   $db->getData("slideshow", "*", "id = '" . OptionsClass::$Url["param"][0] . "'")[0];

 

        return PageClass::view("slideshow");
      
    }






    public function delete()
    {
        global $db;
        $db->delete("slideshow", "id = '" . OptionsClass::$Url["param"][0] . "'");

        PageClass::redirect(OptionsClass::$Url["component"], "deleted");
        return ".....";
    }
}
?>

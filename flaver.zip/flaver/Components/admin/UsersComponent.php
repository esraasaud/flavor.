
<?php

class UsersComponent
{
    function __construct()
    {
    }

    public function index()
    {
        global $db;
        OptionsClass::$ComponentData = $db->getData("users");
        return PageClass::view("users");
    }






    public function add()
    {
        global $db;
        if (isset($_POST["name"])) {
            PageClass::uplaodFiles();
            $db->insert("users", $_POST); 

        
            PageClass::redirect(OptionsClass::$Url["component"], "added");
            return ".....";
        }

       
        return PageClass::view("users");
    }




    public function edit()
    {
        global $db;
        if (isset($_POST["name"])) {
            PageClass::uplaodFiles();
            $db->update("users", $_POST, "id = '" . OptionsClass::$Url["param"][0] . "'");
            PageClass::redirect(OptionsClass::$Url["component"], "updated");
            return ".....";
        }
        OptionsClass::$ComponentData =   $db->getData("users", "*", "id = '" . OptionsClass::$Url["param"][0] . "'")[0];

 

        return PageClass::view("users");
      
    }






    public function delete()
    {
        global $db;
        $db->delete("users", "id = '" . OptionsClass::$Url["param"][0] . "'");

        PageClass::redirect(OptionsClass::$Url["component"], "deleted");
        return ".....";
    }
}
?>


<?php

class ProductsComponent
{
    function __construct()
    {
    }

    public function index()
    {
        global $db;
        OptionsClass::$ComponentData = $db->getData("products");
        return PageClass::view("products");
    }






    public function add()
    {
        global $db;
        if (isset($_POST["name"])) {
            PageClass::uplaodFiles();
            $db->insert("products", $_POST); 

        
            PageClass::redirect(OptionsClass::$Url["component"], "added");
            return ".....";
        }

        OptionsClass::$ComponentData["products_categories"] =   $db->getData("products_categories");

        return PageClass::view("products");
    }




    public function edit()
    {
        global $db;
        if (isset($_POST["name"])) {
            PageClass::uplaodFiles();
            $db->update("products", $_POST, "id = '" . OptionsClass::$Url["param"][0] . "'");
            PageClass::redirect(OptionsClass::$Url["component"], "updated");
            return ".....";
        }

        OptionsClass::$ComponentData =   $db->getData("products", "*", "id = '" . OptionsClass::$Url["param"][0] . "'")[0];
        OptionsClass::$ComponentData["products_categories"] =   $db->getData("products_categories");

 

        return PageClass::view("products");
      
    }






    public function delete()
    {
        global $db;
        $db->delete("products", "id = '" . OptionsClass::$Url["param"][0] . "'");

        PageClass::redirect(OptionsClass::$Url["component"], "deleted");
        return ".....";
    }
}
?>

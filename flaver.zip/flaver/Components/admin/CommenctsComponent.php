
<?php

class CommenctsComponent
{
    function __construct()
    {
    }

    public function index()
    {
        global $db;
        OptionsClass::$ComponentData = $db->getData("comments");
        return PageClass::view("comments");
    }






    public function add()
    {
        global $db;
        if (isset($_POST["name"])) {
            PageClass::uplaodFiles();
            $db->insert("comments", $_POST); 

        
            PageClass::redirect(OptionsClass::$Url["component"], "added");
            return ".....";
        }

       
        return PageClass::view("comments");
    }




    public function edit()
    {
        global $db;
        if (isset($_POST["name"])) {
            PageClass::uplaodFiles();
            $db->update("comments", $_POST, "id = '" . OptionsClass::$Url["param"][0] . "'");
            PageClass::redirect(OptionsClass::$Url["component"], "updated");
            return ".....";
        }
        OptionsClass::$ComponentData =   $db->getData("comments", "*", "id = '" . OptionsClass::$Url["param"][0] . "'")[0];

 

        return PageClass::view("comments");
      
    }






    public function delete()
    {
        global $db;
        $db->delete("comments", "id = '" . OptionsClass::$Url["param"][0] . "'");

        PageClass::redirect(OptionsClass::$Url["component"], "deleted");
        return ".....";
    }
}
?>

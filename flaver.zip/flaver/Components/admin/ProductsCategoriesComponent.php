
<?php

class ProductsCategoriesComponent
{
    function __construct()
    {
    }

    public function index()
    {
        global $db;
        OptionsClass::$ComponentData = $db->getData("products_categories");
        return PageClass::view("productsCategories");
    }






    public function add()
    {
        global $db;
        if (isset($_POST["name"])) {
            PageClass::uplaodFiles();
            $db->insert("products_categories", $_POST); 


            PageClass::redirect(OptionsClass::$Url["component"], "added");
            return ".....";
        }

       
        return PageClass::view("productsCategories");
    }




    public function edit()
    {
        global $db;
        if (isset($_POST["name"])) {
            PageClass::uplaodFiles();
            $db->update("products_categories", $_POST, "id = '" . OptionsClass::$Url["param"][0] . "'");
            PageClass::redirect(OptionsClass::$Url["component"], "updated");
            return ".....";
        }
        OptionsClass::$ComponentData =   $db->getData("products_categories", "*", "id = '" . OptionsClass::$Url["param"][0] . "'")[0];

 

        return PageClass::view("productsCategories");
      
    }






    public function delete()
    {
        global $db;
        $db->delete("products_categories", "id = '" . OptionsClass::$Url["param"][0] . "'");

        PageClass::redirect(OptionsClass::$Url["component"], "deleted");
        return ".....";
    }
}
?>

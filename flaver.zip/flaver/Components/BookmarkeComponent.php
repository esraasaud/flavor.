
<?php

/** Autoloading The required Classes **/

class BookmarkeComponent
{

    function __construct()
    {
    }






    public function index()
    {
        global $db;
        if (isset($_SESSION["login"])) {
        $table = "bookmarkes";
        $type = "recipe";
        $w =  "obj_type='$type' and  user='{$_SESSION["login"]["id"]}'";

        $data = $db->getData($table, "*", $w);

        foreach ($data  as $d) {

            OptionsClass::$ComponentData["data"][] = $db->getData("recipes", "*", "id='{$d['obj_id']}'")[0];
        }

        OptionsClass::$ComponentData["type"] = "recipe";

        return PageClass::view("Bookmarke");
    } else {

        return PageClass::view("login");
    }




}

public function products()
{
    global $db;

    $table = "bookmarkes";
    $type = "product";
    $w =  "obj_type='$type' and  user='{$_SESSION["login"]["id"]}'";

    $data = $db->getData($table, "*", $w);

    foreach ($data  as $d) {

        OptionsClass::$ComponentData["data"][] = $db->getData("products", "*", "id='{$d['obj_id']}'")[0];
    }
    OptionsClass::$ComponentData["type"] = "product";

    return PageClass::view("Bookmarke");
}
}

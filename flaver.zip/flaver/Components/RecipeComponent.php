
<?php

class RecipeComponent
{

    function __construct()
    {
    }


    public function item()
    {

        global $db;

        $id = OptionsClass::$Url["param"][0];

        $data = $db->getData("recipes", "*", "id ='$id'");

        OptionsClass::$ComponentData["data"] = $data[0];

        OptionsClass::$ComponentData["related"] = $db->getData("recipes", "*", " id<>$id   ORDER BY RAND()  limit 0,3");
        return PageClass::view("RecipeItem");
    }



    public function index()
    {


        global $db;
        $w = "";


        $filter = [];
        if (isset($_GET["filter"])) {
            $filtertmp = explode(";", $_GET["filter"]);
            $sp = "  ";

            foreach ($filtertmp as $f) {

                $ftmp = explode(",", $f);
                if (count($ftmp)  > 1) {
                    $filter[$ftmp[0]] = $ftmp[1];

                    $w .= "$sp `{$ftmp[0]}`='{$ftmp[1]}' ";

                    $sp = " and ";
                }
            }
            OptionsClass::$ComponentData["filter"] = $filter;
        }
        if (isset($_GET["search"])) {

            $w = $w == "" ? "" : " and " . $w;

            $w = " ( name like '%{$_GET["search"]}%' || des like '%{$_GET["search"]}%'  || method like '%{$_GET["search"]}%'  )";
        }

        $w = $w == "" ? "1=1" : $w;
        OptionsClass::$ComponentData["data"] = $db->getData("recipes", "*", $w);

        return PageClass::view("Recipe");
    }

    public function add()
    {
        global $db;
        if (isset($_POST["name"])) {
            PageClass::uplaodFiles();
            $_POS["created"]  = OptionsClass::getDate();

            if ($db->insert("recipes", $_POST)) {
                $_GET["msg"] = "added";
            }
        }
        return PageClass::view("AddRecipe");
    }

    public function like()
    {
        global $db;

        if (isset($_SESSION["login"]["id"])) {

            $id = OptionsClass::$Url["param"][0];
            $table = "likes";
            $type = "recipe";
            $w =  " obj_type='$type' and  obj_id='$id' and  user='{$_SESSION["login"]["id"]}'";

            $data = $db->getData($table, "*", $w);
            $a = "";
            if (count($data) <= 0) {
                $data = [
                    "user" => $_SESSION["login"]["id"],
                    "obj_type" => "$type ",
                    "obj_id" => $id
                ];

                if ($db->insert($table, $data)) {
                    $a = "insert";
                }
            } else {
                $db->delete($table, $w);
                $a = "remove";
            }
        }
        return $a;
    }

    public function bookmarke($type = "recipe")
    {
        global $db;

        if (isset($_SESSION["login"]["id"])) {
            $id = OptionsClass::$Url["param"][0];
            $table = "bookmarkes";
            $type = $type;
            $w =  " obj_type='$type' and  obj_id='$id' and  user='{$_SESSION["login"]["id"]}'";

            $data = $db->getData($table, "*", $w);
            $a = "";
            if (count($data) <= 0) {
                $data = [
                    "user" => $_SESSION["login"]["id"],
                    "obj_type" => $type,
                    "obj_id" => $id
                ];

                if ($db->insert($table, $data)) {
                    $a = "insert";
                }
            } else {
                $db->delete($table, $w);
                $a = "remove";
            }
        }

        return $a;
    }


    static function _is_liked($id)
    {
        global $db;
        if (isset($_SESSION["login"]["id"])) {
            $table = "likes";
            $type = "recipe";
            $w =  " obj_type='$type' and  obj_id='$id' and  user='{$_SESSION["login"]["id"]}'";
            $data = $db->getData($table, "*", $w);
            return (count($data) > 0);
        }
        return false;
    }



    static function _is_cart($id)
    {
        global $db;
        if (isset($_SESSION["login"]["id"])) {
            $table = "bookmarkes";
            $type = "recipe_cart";
            $w =  " obj_type='$type' and  obj_id='$id' and  user='{$_SESSION["login"]["id"]}'";
            $data = $db->getData($table, "*", $w);
            return (count($data) > 0);
        }
        return false;
    }



    static  function _is_bookmart($id)
    {
        global $db;
        if (isset($_SESSION["login"]["id"])) {

            $table = "bookmarkes";
            $type = "recipe";
            $w =  " obj_type='$type' and  obj_id='$id' and  user='{$_SESSION["login"]["id"]}'";
            $data = $db->getData($table, "*", $w);
            return (count($data) > 0);
        }
        return false;
    }


    public function cart()
    {

        $id = OptionsClass::$Url["param"][0];

        if (isset($_SESSION["login"]["id"])) {
            $this->bookmarke("recipe_cart");
            
            PageClass::redirect(OptionsClass::$Path . "cart/item/$id", "");
            
        }
    }
 
}




?>

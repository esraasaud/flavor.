<?php

class UsersComponent
{
    function __construct()
    {
    }

    public function index()
    {
        global $db;



        if (isset($_SESSION["login"])) {

            OptionsClass::$ComponentData["data"] =  $db->getData("recipes", "*", "user='{$_SESSION["login"]['id']}'");

            return PageClass::view("user");
        } else {

            if (isset($_POST["email"])) {
                $v = $db->getData("users", "*", "email = '{$_POST["email"]}' and password = '{$_POST["password"]}'")[0];


                if ($v != null) {
                    $_SESSION["login"] =  $v;

                    PageClass::redirect(OptionsClass::$Url["user"], "login");
                } else {
                    var_dump($v);

                    $_GET["msg"] = "login_error";
                }
            }

            return PageClass::view("login");
        }
    }



    public function logout()
    {

        unset($_SESSION["login"]);
        PageClass::redirect(OptionsClass::$Url["component"], "logout");
    }


    public function  new()
    {
        global $db;
        if (isset($_POST["name"])) {
            PageClass::uplaodFiles();
            $db->insert("users", $_POST);
            PageClass::redirect(OptionsClass::$Url["component"], "user_add");
            return ".....";
        }


        return PageClass::view("newuser");
    }




    public function myprofile()
    {
        global $db;
        if (isset($_POST["name"])) {
            PageClass::uplaodFiles();
            $db->update("users", $_POST, "id = '" . $_SESSION["login"]['id']  . "'");
            PageClass::redirect(OptionsClass::$Url["component"], "updated");
            return ".....";
        }
        OptionsClass::$ComponentData =   $db->getData("users", "*", "id = '" . $_SESSION["login"]['id'] . "'")[0];



        return PageClass::view("MyProfile");
    }






    public function delete()
    {
        global $db;
        $db->delete("users", "id = '" . OptionsClass::$Url["param"][0] . "'");

        PageClass::redirect(OptionsClass::$Url["component"], "deleted");
        return ".....";
    }



    public function follow()
    {
        global $db;

        if (isset($_SESSION["login"]["id"])) {

            $id = OptionsClass::$Url["param"][0];
            $table = "follow";
            $w =  "follower='$id' and  user='{$_SESSION["login"]["id"]}'";

            $data = $db->getData($table, "*", $w);
            $a = "";
            if (count($data) <= 0) {
                $data = [
                    "user" => $_SESSION["login"]["id"],
                    "follower" => $id
                ];

                if ($db->insert($table, $data)) {
                    $a = "insert";
                }
            } else {
                $db->delete($table, $w);
                $a = "remove";
            }
        }
        return $a;
    }

    static  function _is_follow($id)
    {


        global $db;
        if (isset($_SESSION["login"]["id"])) {
            $table = "follow";
            $w =  " follower='$id' and  user='{$_SESSION["login"]["id"]}'";
            $data = $db->getData($table, "*", $w);


            return (count($data) > 0);
        }
        return false;
    }




    static function getUserBlock($id)
    {


        if ($id == "0") {
            echo "@زائر";
        } else {
            global $db;
            $us =  $db->getData("users", "*", "id='$id'");
            if ($us  != null) {
                $u = $us[0]
?>



                <div class="col-12">
                    <div class="profile">


                        <div style='float:right' class="profile-image">
                            <img style="height:60px;" src=" <?= OptionsClass::$UploadFloder . $u["image"] ?>" alt="">
                        </div>
                        <span style="    padding-right: 16px;
    display: inline-block;
    margin-top: 0;">

                            <a href="<?= OptionsClass::$Path ?>Recipe/?filter=;user,<?= $id ?>">
                                <h5 class="profile-user-name"><?= $u["name"] ?></h5>

                            </a>


                            <?php if(isset($_SESSION["login"]["id"]) && $id ==$_SESSION["login"]["id"]){

?>
 <?php
                            }else{
?>

<a href="#" class="follow_btn <?= UsersComponent::_is_follow($id) ?  "act" : ""  ?>" onclick="_setlike(event,this)" data-url="<?= OptionsClass::$Path ?>users/follow/<?= $u["id"] ?>">
                                <i class="bi bi-person-plus-fill"></i>
                            </a>
                     
<?php

                                
                            } ?>
                      
                           

                        </span>

                    </div>
                </div>



<?php

            } else {
                echo "@زائر";
            }
        }
    }
}
?>

<?php

/** Autoloading The required Classes **/

class indexComponent
{

    function __construct()
    {
    }

    public function index()
    {
        global $db;

        OptionsClass::$ComponentData["slideshow"] = $db->getData("slideshow");

        


        OptionsClass::$ComponentData["recipes"] = $db->getData("recipes", "*", "  1=1  ORDER BY RAND()  limit 0,3");


        return PageClass::view("index");

    }

    public function login()
    {

        echo "Login Method";
    }

    public function showUsers()
    {
    }
}
?>

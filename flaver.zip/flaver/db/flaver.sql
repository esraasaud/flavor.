-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Mar 22, 2021 at 09:40 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `flaver`
--

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `obj_type` varchar(255) NOT NULL,
  `obj_id` int(11) NOT NULL,
  `comment` text NOT NULL,
  `user` varchar(255) NOT NULL,
  `created` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `obj_type`, `obj_id`, `comment`, `user`, `created`) VALUES
(7, 'recipe', 3, 'dasdasd', 'زائر', '2021-03-21 21:53:31'),
(8, 'recipe', 3, 'dfsdfsdf', 'محمد عبد الله ', '2021-03-21 21:54:04'),
(9, 'recipe', 3, 'sdfsdfsdf', 'محمد عبد الله ', '2021-03-21 21:54:21'),
(10, 'recipe', 3, 'sdfsdfsdf', '5', '2021-03-21 21:54:32'),
(11, 'recipe', 3, 'ffffffff', '5', '2021-03-21 21:58:40'),
(12, 'recipe', 4, 'fsdf asdasasdasd', '5', '2021-03-21 23:20:23'),
(13, 'recipe', 4, 'dasdasd', '0', '2021-03-21 23:20:47'),
(14, 'recipe', 4, 'جيد', '3', '2021-03-21 23:24:44'),
(15, 'recipe', 4, 'شسيشسيشسيشسي', '0', '2021-03-21 23:25:11'),
(16, 'products', 33, '77777777', '6', '2021-03-21 23:31:57');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `name` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `des` text DEFAULT NULL,
  `id` int(11) NOT NULL,
  `user` int(11) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `products` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`name`, `image`, `des`, `id`, `user`, `address`, `email`, `phone`, `products`) VALUES
('asdas', NULL, 'asd', 3, NULL, 'dasd', 'البريد اللكتasdasرونى', 'الdasdasdتليفون', '{\"33\":\"6\",\"45\":\"5\",\"46\":\"4\",\"47\":\"2\"}'),
(' حسام احمد22', NULL, 'sdasd', 5, NULL, 'asda', 'aa222a@aaa.com', '45222645564', '{\"47\":\"6\",\"48\":\"5\",\"45\":\"4\",\"33\":\"3\"}'),
(' حسام احمد22', NULL, 'sdasd', 6, NULL, 'asda', 'aa222a@aaa.com', '45222645564', 'null');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `des` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `cat_id` int(11) NOT NULL,
  `price` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `des`, `image`, `cat_id`, `price`) VALUES
(33, 'طماطم', 'طماطم جيدية طماطم جيدية طماطم جيدية طماطم جيدية طماطم جيدية ', '605759c740834.jpg', 1, '5'),
(45, 'فلفل', 'شسيشسيسش', '60575b724968d.jpg', 1, '6'),
(46, 'جزر', 'شسيشسيسش', '60575b9c23f85.jpg', 1, '3'),
(47, 'حبوب', 'حبوب ١حبوب ١حبوب ١حبوب ١حبوب ١حبوب ١حبوب ١حبوب ١', '60575beb568d6.jpg', 2, '2'),
(48, 'ليمون', 'حبوب ١حبوب ١حبوب ١حبوب ١حبوب ١حبوب ١حبوب ١حبوب ١', '60575c0caf6a9.jpg', 3, '2');

-- --------------------------------------------------------

--
-- Table structure for table `products_categories`
--

CREATE TABLE `products_categories` (
  `name` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `des` text DEFAULT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products_categories`
--

INSERT INTO `products_categories` (`name`, `image`, `des`, `id`) VALUES
('خضروات', NULL, '', 1),
('حبوب', NULL, '', 2),
('فاكهة', NULL, '', 3),
('عسل', NULL, '', 4),
('مخبازات', NULL, 'سيشسيشسي', 5),
('مخبازات', NULL, 'سيشسيشسي', 6);

-- --------------------------------------------------------

--
-- Table structure for table `recipes`
--

CREATE TABLE `recipes` (
  `name` varchar(255) NOT NULL,
  `method` text NOT NULL,
  `des` text DEFAULT NULL,
  `difficulty` varchar(255) DEFAULT NULL,
  `meal` varchar(255) DEFAULT NULL,
  `calories` varchar(255) DEFAULT NULL,
  `fats` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `video` varchar(255) DEFAULT NULL,
  `id` int(11) NOT NULL,
  `time` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `user` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `recipes`
--

INSERT INTO `recipes` (`name`, `method`, `des`, `difficulty`, `meal`, `calories`, `fats`, `image`, `video`, `id`, `time`, `created`, `user`) VALUES
('الصوفه الثانية ', 'الصوفه الثانية الصوفه الثانية الصوفه الثانية الصوفه الثانية الصوفه الثانية الصوفه الثانية الصوفه الثانية ', 'المقادير', 'مستوى الصعوبة', 'الوقت', '', '', '6055d9f2f172e.jpg', '6055d9f2f172e.jpg', 1, '40', '2021-03-09 16:51:39', 3),
(' إسم المنتج', 'الطريقة', 'المقادير', 'مستوى الصعوبة', 'الوقت', '', '', '6055d9f2f172e.jpg', '6055d9f2f172e.jpg', 2, '10', '2021-03-03 16:51:45', 5),
('الصوفة الاولى ', 'الصوفة الاولى  الصوفة الاولى الصوفة الاولى الصوفة الاولى الصوفة الاولى الصوفة الاولى الصوفة الاولى الصوفة الاولى ', 'المقادير', 'easy', '10', 'السعارات الحرارية', 'الدهون', '6055d9f2f172e.jpg', '6055d9f2f172e.jpg', 3, '10', '2021-03-20 16:51:47', 3),
('عمل شاى', ' عمل شاى  عمل شاى  عمل شاى  عمل شاى  عمل شاى  عمل شاى  عمل شاى ', 'مياء شاى مياء شاى مياء شاى مياء شاى ', 'easy', 'lunch', '٥', '٥', '6057c496a2be0.jpg', '6057c496a2cd5.jpg', 4, '20', NULL, 3);

-- --------------------------------------------------------

--
-- Table structure for table `slideshow`
--

CREATE TABLE `slideshow` (
  `name` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `des` text DEFAULT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `slideshow`
--

INSERT INTO `slideshow` (`name`, `image`, `des`, `id`) VALUES
('   اهلا بك الى مذاق2222', '60576656ac5f2.jpg', '    تصفحي في موقعنا عن كل الوصفات والاطباق من كل العالم متوفرة بين يديك \r\n', 1),
('منتج واحد', '6057664aa1ccf.jpg', ' منتج واحد منتج واحد منتج واحد', 2);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `address` text NOT NULL,
  `phone` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `type`, `image`, `address`, `phone`) VALUES
(3, 'محمد عبد الله ', 'user@gmail.com', 'user', NULL, '6057a22026bac.jpg', ' الممكلة السعودية الرياض', '123456'),
(5, 'شمياء احمد', 'admin@gmail.com', 'admin', 'admin', '6057bd984ebc3.jpg', ' الممكلة السعودية الرياض', '123456'),
(6, ' حسام احمد', 'aaa@aaa.com', 'aaa', NULL, '6057c88175bd9.jpg', 'dasdasd adasd', '45645564'),
(7, ' حسام احمد', 'aaa@aaa.com', 'aaa', NULL, NULL, 'dasdasd adasd', '45645564');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products_categories`
--
ALTER TABLE `products_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `recipes`
--
ALTER TABLE `recipes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `slideshow`
--
ALTER TABLE `slideshow`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `products_categories`
--
ALTER TABLE `products_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `recipes`
--
ALTER TABLE `recipes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `slideshow`
--
ALTER TABLE `slideshow`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<?php
class MainMenuModule{

    var $p; 
    function __construct($options =null)
    {
        $this->p = $options;
    }

    public function index()
    {

       return PageClass::view("MainMenu");
    }


}

?>
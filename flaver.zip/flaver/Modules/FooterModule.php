<?php
class FooterModule{

    var $p; 
    function __construct($options =null)
    {
        $this->p = $options;
    }

    public function index()
    {

       return PageClass::view("Footer");
    }


}

?>
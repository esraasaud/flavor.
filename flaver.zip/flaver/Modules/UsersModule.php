<?php
class UsersModule{

    var $p; 
    function __construct($options =null)
    {
        $this->p = $options;
    }

    public function index()
    {

        return "Modules Method";
    }


}

?>
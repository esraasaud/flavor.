<div class="all-title-box">
   <div class="container">
      <div class="row">
         <div class="col-lg-12">
            <h2> عربة التسوق</h2>

         </div>
      </div>
   </div>
</div>



<div style='padding: 18px; background: #eee; ' class="user_bar">
   <div class="container">

      <?php
      global $db;
      $uid =   $_SESSION["login"]["id"];
      UsersComponent::getUserBlock($uid);
      ?>
   </div>
</div>


<div class="container">

   <div class="row">
      <div class="col-2">
      </div>

      <div class="col-8">

         <br />

         <?php


         if (OptionsClass::$Action  == "item") {
            $v = OptionsClass::$ComponentData["data"];

         ?>
            <img style="border-radius: 25px; ;" src="<?= OptionsClass::$UploadFloder . $v["image"] ?>" class="img-fluid" alt="Image">


            <h4 class="item_title">
               <?= $v["name"] ?>
            </h4>




            <div class="hlight-area col-12">
               <?php
               $d = explode(",",    $v["des"]);
               echo '<ol>';
               foreach ($d as $i) {

                  $isch = CartComponent::_is_chek($v["id"], $i) ? ' checked ' : '';
                  $url = OptionsClass::$Path . "cart/check/{$v["id"]}/$i";
                  $url = OptionsClass::$Path . "cart/check/{$v["id"]}/$i";

                  echo "<li class='$isch' >
                  <input type='checkbox' data-url='$url'     $isch  onclick='_check(event, this)'     />
                  $i  </li>";
               }
               echo '</ol>';
               ?>
            </div>

      </div>
   </div>

</div>

</div>



<?php




         } else {

            if (OptionsClass::$ComponentData["data"] != null) {

?><div class='row'><?php

                     foreach (OptionsClass::$ComponentData["data"] as $v) {
                        UI::recipeItBlockCart($v);
                     }

                     ?></div><?php
                     } else {
                        echo  MessageClass::info(OptionsClass::$Lang["nodata_msg"], true);
                     }
                  }


                        ?>

</div>

<script>
   function _check(event, th) {


      var url = th.dataset.url;

      ajax(url, function(o) {
         if (th.parentNode.classList.contains("checked")) {
            th.parentNode.classList.remove("checked");
         } else {
            th.parentNode.classList.add("checked");

         }
      })

   }
</script>
<style>
   .checked {

      text-decoration: line-through;
      color: #a0a0a0;
   }
</style>
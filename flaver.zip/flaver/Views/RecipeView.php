<?php


function _chekFilter($name, $value)
{

   if (isset(OptionsClass::$ComponentData["filter"][$name])) {
      if (OptionsClass::$ComponentData["filter"][$name] == $value) {

         return " active ";
      } else {
         return "";
      }
   } else {


      return "";
   }
}


?>


<div class="all-title-box">
   <div class="container">
      <div class="row">
         <div class="col-lg-12">
            <h2>الوصفات</h2>

         </div>
      </div>
   </div>
</div>



<?php

if (isset($_GET["msg"])) {

   echo  MessageClass::success(OptionsClass::$Lang[$_GET["msg"] . "_msg"], true);
}

?>

<main class='main'>
   <div class="container">

      <div class="row">

         <div class="col-xl-3 col-lg-3 col-sm-12 col-xs-12 sidebar-shop-left">
            <div class="product-categori">
               <div class="search-product">
                  <form >
                     <input class="form-control _input_search" 
                     
                     value=' <?=$_GET["search"]==null ? "":$_GET["search"] ?>'
                     
                     name="search" placeholder=" ابحث هنا ..." type="text">
                     <button type="submit" > <i class="bi bi-search"></i> </button>
                  </form>
               </div>
               <div class="filter-sidebar-left">
                  <div class="title-left">
                     <h3>التصنيفات</h3>
                  </div>
                  <div class="list-group list-group-collapse list-group-sm list-group-tree" id="list-group-men" data-children=".sub-men">
                     <div class="list-group-collapse sub-men">
                        <a class="list-group-item list-group-item-action" href="#sub-men1" data-toggle="collapse" aria-expanded="true" aria-controls="sub-men1"> الوجبة
                        </a>
                        <div class="collapse show data_filter" data-filter="meal" id="sub-men1" data-parent="#list-group-men">
                           <div class="list-group">
                              <a href="#" data-name="meal" data-value="breakfast" class="list-group-item list-group-item-action <?= _chekFilter("meal", "breakfast") ?> ">فطور <small class="text-muted"></small></a>
                              <a href="#" data-name="meal" data-value="lunch" class="list-group-item list-group-item-action <?= _chekFilter("meal", "lunch") ?> ">غداء <small class="text-muted"></small></a>
                              <a href="#" data-name="meal" data-value="dinner" class="list-group-item list-group-item-action <?= _chekFilter("meal", "dinner") ?> ">عشاء <small class="text-muted"></small></a>
                              <a href="#" data-name="meal" data-value="Sweetening" class="list-group-item list-group-item-action <?= _chekFilter("meal", "Sweetening") ?> ">تحلية<small class="text-muted"></small></a>
                              <a href="#" data-name="meal" data-value="Sidedishes" class="list-group-item list-group-item-action <?= _chekFilter("meal", "Sidedishes") ?> "> اطباق جانبية<small class="text-muted"></small></a>
                           </div>
                        </div>
                     </div>
                     <div class="list-group-collapse sub-men">
                        <a class="list-group-item list-group-item-action" href="#sub-men2" data-toggle="collapse" aria-expanded="false" aria-controls="sub-men2">مستوى الصعوبة

                        </a>
                        <div class="  data_filter" data-filter="difficulty" data-parent="#list-group-men">
                           <div class="list-group">
                              <a href="#" data-name="difficulty" data-value="easy" class="list-group-item list-group-item-action<?= _chekFilter("difficulty", "easy") ?> ">سهل <small class="text-muted"></small></a>
                              <a href="#" data-name="difficulty" data-value="mid" class="list-group-item list-group-item-action<?= _chekFilter("difficulty", "mid") ?> ">متوسط <small class="text-muted"></small></a>
                              <a href="#" data-name="difficulty" data-value="hard" class="list-group-item list-group-item-action<?= _chekFilter("difficulty", "hard") ?> ">محترف <small class="text-muted"></small></a>
                           </div>
                        </div>
                     </div>
                     <div class="list-group-collapse sub-men">
                        <a class="list-group-item list-group-item-action" href="#sub-men1" data-toggle="collapse" aria-expanded="true" aria-controls="sub-men1"> الوقت
                        </a>
                        <div class="   data_filter" data-filter="time" id="sub-men1" data-parent="#list-group-men">
                           <div class="list-group">
                              <a href="#" data-name="time" data-value="50" class="list-group-item list-group-item-action<?= _chekFilter("time", "50") ?> ">50 دقيقة فاكثر</a>
                              <a href="#" data-name="time" data-value="40" class="list-group-item list-group-item-action<?= _chekFilter("time", "40") ?> ">اقل من40 دقيقة<small class="text-muted"></small></a>
                              <a href="#" data-name="time" data-value="30" class="list-group-item list-group-item-action<?= _chekFilter("time", "30") ?> "> اقل من 30 دقيقة<small class="text-muted"></small></a>
                              <a href="#" data-name="time" data-value="20" class="list-group-item list-group-item-action<?= _chekFilter("time", "20") ?> ">اقل من 20 دقيقة<small class="text-muted"></small></a>
                              <a href="#" data-name="time" data-value="10" class="list-group-item list-group-item-action<?= _chekFilter("time", "10") ?> ">اقل من 10 دقائق<small class="text-muted"></small></a>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="filter-price-left">

               </div>
            </div>
         </div>

         <div class="col-xl-9 col-lg-9 col-sm-12 col-xs-12 shop-content-right">
            <div class="right-product-box">
               <div class="product-item-filter row">


                  <div class="col-7 col-sm-7 text-center text-sm-left">
                  </div>

                  <div class="col-3 col-sm-3 text-center text-sm-left">
                     <div class="toolbar-sorter-right">

                        <select id="basic" class="selectpicker show-tick form-control">
                           <option data-display="Select">الاحدث</option>
                           <option value="1">الأشهر</option>
                           <option value="2">الاقل مكونات</option>
                           <option value="3">الاسرع في التحضير</option>

                        </select>

                     </div>

                  </div>



                  <div class="col-2 col-sm-2 text-center text-sm-right">
                     <ul class="nav nav-tabs ml-auto">
                        <li>
                           <a class="nav-link active" href="#grid-view" data-toggle="tab"> <i class="bi bi-list-ul"></i> </a>
                        </li>
                        <li>
                           <a class="nav-link" href="#list-view" data-toggle="tab"> <i class="bi bi-grid-fill"></i> </a>
                        </li>
                     </ul>
                  </div>





               </div>


               <div style='    padding: 18px; background: #eee; margin-top: 22px;' class="user_bar">


                  <?php
                  if (isset(OptionsClass::$ComponentData["filter"]["user"])) {

                     global $db;
                     $uid = OptionsClass::$ComponentData["filter"]["user"];
                     UsersComponent::getUserBlock($uid);


                  ?>

                     <table class='table'>
                        <tr>
                           <th> المتابعين</th>
                           <th> المتابعون</th>
                           <th> المشاركات</th>

                        </tr>


                        <tr>
                           <td>
                              <?php
                              echo Count($db->getData("follow", "*", "user='$uid'"));
                              ?>
                           </td>
                           <td> <?php
                                 echo Count($db->getData("follow", "*", "follower='$uid'"));
                                 ?>
                           </td>
                           <td> <?php
                                 echo Count($db->getData("recipes", "*", "user='$uid'"));
                                 ?>
                           </td>

                        </tr>
                     </table>

                  <?php

                  }
                  ?>


               </div>
               <div class="product-categorie-box">
                  <div class="tab-content">
                     <div role="tabpanel" class="tab-pane fade show active" id="grid-view">
                        <div class="row">
                           <?php
                           foreach (OptionsClass::$ComponentData["data"] as $k => $v) {
                              UI::recipeItBlock($v);
                            } ?>
                        </div>
                     </div>


                  </div>
               </div>
            </div>
         </div>


      </div>
   </div>

</main>


<script>
   document.querySelectorAll(".data_filter a").forEach(function(obj) {
      obj.onclick = function(event) {
         event.preventDefault();
         var p = obj.parentNode.parentNode;
         p.querySelectorAll("a").forEach(function(a) {
            a.classList.remove("active");
         })
         obj.classList.add("active");
         _function_get_filter();

      };


   })


  


   function _function_get_filter() {
      var f = "";



      document.querySelectorAll(".data_filter a.active").forEach(function(a) {

         if (a.dataset.value != null) {
            f += ";" + a.dataset.name +
               "," + a.dataset.value;
         }

      })

      if (f != "") {
         window.location = "?filter=" + f;

      }


   }
</script>
<form method="POST" enctype="multipart/form-data">
        
        
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">  إسم  </label>
            <input type="text" name="name" value="<?= OptionsClass::getValue("name") ?>" 
            
            class="form-control" >
        </div>




        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">  البريد  </label>
            <input type="text" name="email" value="<?= OptionsClass::getValue("email") ?>" 
            
            class="form-control" >
        </div>
        <div class="mb-3">
            <label class="form-label"> كلمة السر   </label>
            <input type="password" name="password" value="<?= OptionsClass::getValue("password") ?>" class="form-control" 
           >
        </div>







        <div class="col-12">
                        <label class="form-label"> التليفون </label>
                        <input type="text" name="phone" class="form-control"  value="<?= OptionsClass::getValue("phone") ?>"  aria-describedby="emailHelp">
                    </div>






                    <div class="col-12">
                        <label class="form-label"> النوع </label>
                        <input type="text" name="type" class="form-control"   value="<?= OptionsClass::getValue("type") ?>" aria-describedby="emailHelp">
                    </div>








        <div class="mb-3">
            <label for="formFile" class="form-label"> صورة</label>
            <input class="form-control" type="file" name="image" id="formFile">
        </div>
        <hr />
        <div class="d-grid gap-2 d-md-flex justify-content-md-end">
            <button type="reset" class="btn  btn-outline-secondary ">مسح</button>
            <button type="submit" class="btn btn-lg  btn-primary me-md-2"> إرسال</button>
        </div>

    </form>

		
		
<div class="all-title-box">
   <div class="container">
      <div class="row">
         <div class="col-lg-12">
            <h2>صفحتى الشخصية</h2>

         </div>
      </div>
   </div>
</div>
		
		

<div style='padding: 18px; background: #eee; ' class="user_bar">
<div class="container">

<?php

global $db;
$uid =   $_SESSION["login"]["id"];
UsersComponent::getUserBlock($uid);


?>


<table class='table'>
	<tr>
		<th> المتابعين</th>
		<th> المتابعون</th>
		<th> المشاركات</th>

	</tr>


	<tr>
		<td>
			<?php
			echo Count($db->getData("follow", "*", "user='$uid'"));
			?>
		</td>
		<td> <?php
				echo Count($db->getData("follow", "*", "follower='$uid'"));
				?>
		</td>
		<td> <?php
				echo Count($db->getData("recipes", "*", "user='$uid'"));
				?>
		</td>

	</tr>
</table>




</div> 

		</div><?php


function _chekFilter($name, $value)
{

   if (isset(OptionsClass::$ComponentData["filter"][$name])) {
      if (OptionsClass::$ComponentData["filter"][$name] == $value) {

         return " active ";
      } else {
         return "";
      }
   } else {


      return "";
   }
}


?>





<?php

if (isset($_GET["msg"])) {

   echo  MessageClass::success(OptionsClass::$Lang[$_GET["msg"] . "_msg"], true);
}

?>

<main class='main'>
   <div class="container">
<h3> منشوراتي</h3>
      <div class="row">

         

         <div class="col-12 shop-content-right">
            



               <div class="product-categorie-box">
                  <div class="tab-content">
                     <div role="tabpanel" class="tab-pane fade show active" id="grid-view">
                        <div class="row">

                           <?php
                           foreach (OptionsClass::$ComponentData["data"] as $k => $v) {
                           ?>
                              <div class="col-md-6 col-lg-4 col-xl-4">
                                 <div class="blog-box">


                                    <div class="blog-img">
                                       <img src="<?= OptionsClass::$UploadFloder . $v["image"] ?>" class="img-fluid" alt="Image">
                                    </div>



                                    <div class="blog-content">
                                       <div class="title-blog">
                                          <?php UsersComponent::getUserBlock($v["user"]); ?>

                                          <br />
                                          <h3> <?= $v["name"] ?> </h3>
                                          <p><?= $v["des"] ?></p>
                                       </div>



                                    </div>
                                    <ul class="option-blog">
                                       <li><a class="<?= RecipeComponent::_is_liked($v["id"]) ?  "act" : ""  ?>" href="#" onclick="_setlike(event,this)" data-url="<?= OptionsClass::$Path ?>Recipe/like/<?= $v["id"] ?>"><i class="bi bi-heart"></i></a></li>
                                       <li> <a class="<?= RecipeComponent::_is_bookmart($v["id"]) ?  "act" : ""  ?>" href="#" onclick="_setbookmark(event,this)" data-url="<?= OptionsClass::$Path ?>Recipe/bookmarke/<?= $v["id"] ?>"> <i class="bi bi-bookmark"></i></a></li>
                                       <li><a href="<?= OptionsClass::$Path ?>Recipe/item/<?= $v["id"] ?>"><i class="bi bi-eye"></i></a></li>
                                    </ul>

                                 </div>
                              </div>




                           <?php } ?>


                        </div>
                     </div>


                  </div>
               </div>
            </div>
         </div>


   </div>

</main>


<script>
   document.querySelectorAll(".data_filter a").forEach(function(obj) {
      obj.onclick = function(event) {
         event.preventDefault();
         var p = obj.parentNode.parentNode;
         p.querySelectorAll("a").forEach(function(a) {
            a.classList.remove("active");
         })
         obj.classList.add("active");
         _function_get_filter();

      };


   })


   function _function_get_filter() {
      var f = "";



      document.querySelectorAll("a.active").forEach(function(a) {

         if (a.dataset.value != null) {
            f += ";" + a.dataset.name +
               "," + a.dataset.value;
         }

      })

      if (f != "") {
         window.location = "?filter=" + f;

      }


   }
</script>
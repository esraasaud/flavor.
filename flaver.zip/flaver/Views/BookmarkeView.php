<br />
<br />
<div class="container">

	<div style='padding: 18px; background: #eee; margin-top: 22px;' class="user_bar">


		<?php

		global $db;
		$uid =   $_SESSION["login"]["id"];
		UsersComponent::getUserBlock($uid);


		?>

		<table class='table'>
			<tr>
				<th> المتابعين</th>
				<th> المتابعون</th>
				<th> المشاركات</th>

			</tr>


			<tr>
				<td>
					<?php
					echo Count($db->getData("follow", "*", "user='$uid'"));
					?>
				</td>
				<td> <?php
						echo Count($db->getData("follow", "*", "follower='$uid'"));
						?>
				</td>
				<td> <?php
						echo Count($db->getData("recipes", "*", "user='$uid'"));
						?>
				</td>

			</tr>
		</table>




	</div> 
	
	<br />
	<br />
	<div class="row">


		<div class=" col-3">
			<?= PageClass::view("Follow"); ?>
			<br />
			<br />
			<br />
			<br />

		</div>



		<div class="col-9">
			<div class="special-menu text-center">
				<div class="button-group filter-button-group">



					<?php

					if (OptionsClass::$ComponentData["type"] == "product") {


					?>


						<a href="<?= OptionsClass::$Path ?>bookmarke/"> <button class="active" data-filter=".top-featured"> وصفات</button></a>

						




					<?php
					} else {
					?>


						<a href="<?= OptionsClass::$Path ?>bookmarke/"> <button data-filter=".top-featured"> وصفات</button></a>

						


					<?php
					}
					?>



				</div>
			</div>





			<div class="row special-list col-12">
				<div class="row">


					<?php

					if (OptionsClass::$ComponentData["type"] == "product") {
						foreach (OptionsClass::$ComponentData["data"] as $k => $v) {
					?>
							<div class="col-sm-6 col-md-6 col-lg-4 col-xl-4">
								<div class="products-single fix">
									<div class="box-img-hover">
										<div class="type-lb">

										</div>
										<img src="<?= OptionsClass::$UploadFloder . $v["image"] ?>" class="img-fluid" alt="Image">

										<div class="mask-icon">
											<ul>
												<li><a href="<?= OptionsClass::$Path ?>products/item/<?= $v["id"] ?>" data-toggle="tooltip" data-placement="right" title="عرض"><i class="bi bi-eye"></i></a></li>
												<li><a class="<?= ProductsComponent::_is_liked($v["id"]) ?  "act" : ""  ?>" href="#" onclick="_setlike(event,this)" data-url="<?= OptionsClass::$Path ?>products/like/<?= $v["id"] ?>" data-toggle="tooltip" data-placement="right" title="اضافة الى الإشارات المرجعية"><i class="bi bi-bookmark"></i></a></li>
												<li><a class="<?= ProductsComponent::_is_bookmart($v["id"]) ?  "act" : ""  ?>" href="#" onclick="_setbookmark(event,this)" data-url="<?= OptionsClass::$Path ?>products/bookmarke/<?= $v["id"] ?>" data-toggle="tooltip" data-placement="right" title="اعجاب"><i class="bi bi-heart"></i></a></li>
											</ul>
											<span class="cart ">
												<div class="row">
													<div class="input-group btn-group-sm col-6">
														<div data-cartvalue="._cart_value_<?= $v["id"] ?>" class="input-group-text  _cart_value_p" id="btnGroupAddon2">+</div>
														<input type="text" class="form-control _cart_value_<?= $v["id"] ?>" style="width: 30px; text-align: center;" value="1" aria-describedby="btnGroupAddon2">
														<div data-cartvalue="._cart_value_<?= $v["id"] ?>" class="input-group-text _cart_value_m" id="btnGroupAddon2">-</div>
													</div>
												</div> <a class=" add_tocart" data-cartvalue="._cart_value_<?= $v["id"] ?>" data-url="<?= OptionsClass::$Path ?>cart/add/<?= $v["id"] ?>" href="#">
													اضافة الى قائمة التسوق
												</a>
											</span>
										</div>
									</div>
									<div class="why-text">
										<h4>
											<?= $v["name"] ?>
										</h4>

										<div class="price">
											<?= $v["price"] ?>
											ر ٫س
										</div>

									</div>
								</div>
							</div>
						<?php
						}
					} else {
if (OptionsClass::$ComponentData["data"]!=null){
						foreach (OptionsClass::$ComponentData["data"] as $v) {
						?>

							<div class="col-md-6 col-lg-4 col-xl-4">
								<div class="blog-box">


									<div class="blog-img">
										<img src="<?= OptionsClass::$UploadFloder . $v["image"] ?>" class="img-fluid" alt="Image">
									</div>



									<div class="blog-content">
										<div class="title-blog">
											<?php

											if ($v["user"] == "0") {
												echo "@زائر";
											} else {
												global $db;
												$us =  $db->getData("users", "*", "id='{$v["user"]}'");
												if ($us  != null) {
													$u = $us[0]
											?>
													<div class="col-12">
														<div class="profile">
															<div style='float:right' class="profile-image">
																<img style="height:60px;" src=" <?= OptionsClass::$UploadFloder . $u["image"] ?>" alt="">
															</div>

															<span style="padding: 16px;display: inline-block;margin-top: -20px;">
																<h5 class="profile-user-name"><?= $u["name"] ?></h5>
																<a href="#" class="follow_btn <?= UsersComponent::_is_follow($v["id"]) ?  "act" : ""  ?>" onclick="_setlike(event,this)" data-url="<?= OptionsClass::$Path ?>users/follow/<?= $u["id"] ?>">
																	<i class="bi bi-person-plus-fill"></i>
																</a>
															</span>

														</div>
													</div>
											<?php
												} else {
													echo "@زائر";
												}
											}
											?>
											<br />
											<h3><?= $v["name"] ?></h3>
											<p> <?= $v["des"] ?></p>
										</div>



									</div>
									<ul class="option-blog">
										<li><a class="<?= RecipeComponent::_is_liked($v["id"]) ?  "act" : ""  ?>" href="#" onclick="_setlike(event,this)" data-url="<?= OptionsClass::$Path ?>Recipe/like/<?= $v["id"] ?>"><i class="bi bi-heart"></i></a></li>
										<li> <a class="<?= RecipeComponent::_is_bookmart($v["id"]) ?  "act" : ""  ?>" href="#" onclick="_setbookmark(event,this)" data-url="<?= OptionsClass::$Path ?>Recipe/bookmarke/<?= $v["id"] ?>"> <i class="bi bi-bookmark"></i></a></li>
										<li><a href="<?= OptionsClass::$Path ?>Recipe/item/<?= $v["id"] ?>"><i class="bi bi-eye"></i></a></li>
									</ul>
								</div>
							</div>




					<?php

}
						}else{

							echo  MessageClass::info(OptionsClass::$Lang["nodata_msg"], true);

						}
					}

					?>
				</div>
			</div>
		</div>
	</div>
</div>
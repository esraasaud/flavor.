<?php

$v = OptionsClass::$ComponentData["data"];
$r = OptionsClass::$ComponentData["related"];
OptionsClass::$ComponentData["comments"]=["id"=>$v["id"],"type"=>"products"];
?>


<div class="all-title-box">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h2>



                    <?= $v["name"] ?>
                </h2>

            </div>
        </div>
    </div>
</div>



<?php

if (isset($_GET["msg"])) {

    echo  MessageClass::success(OptionsClass::$Lang[$_GET["msg"] . "_msg"], true);
}
?>

<main class='main'>



    <div class="container">

        <div class="row">

            <div class="col-sm-4 col-4">
                <?= PageClass::view("Follow"); ?>
                <br />
                <br />
                <br />
                <br />
                <?= PageClass::view("Related"); ?>


            </div>


            <div class="col-sm-8 col-md-8 col-8">

                <div style="padding:25px;">




                    <img style="border-radius: 25px; ;" src="<?= OptionsClass::$UploadFloder . $v["image"] ?>" class="img-fluid" alt="Image">


                    <div class="item_icons">
                        <ul>
                           
                           


                                        <li><a    class="<?= ProductsComponent::_is_liked($v["id"]) ?  "act" : ""  ?>" href="#" onclick="_setlike(event,this)"  data-url="<?= OptionsClass::$Path ?>products/like/<?= $v["id"] ?>" 
                                        data-toggle="tooltip" data-placement="right" title="اضافة الى الإشارات المرجعية"><i class="bi bi-heart"></i></a></li>
                                        <li><a  class="<?= ProductsComponent::_is_bookmart($v["id"]) ?  "act" : ""  ?>" href="#" onclick="_setbookmark(event,this)" 
                                          data-url="<?= OptionsClass::$Path ?>products/bookmarke/<?= $v["id"] ?>" 
                                         data-toggle="tooltip" data-placement="right" title="اعجاب"><i class="bi bi-bookmark"></i></a></li>


                            <li><a href="#" data-toggle="tooltip" data-placement="right" title="اعجاب"><i class="bi bi-facebook"></i></a></li>
                            <li><a href="#" data-toggle="tooltip" data-placement="right" title="اعجاب"><i class="bi bi-twitter"></i></a></li>


                        </ul>
                    </div>





<div class="row">



<div class='item_info  col-3'>



                     


<!-- Post Comment & Share Area -->
<div style="float:left" class="post-comment-share-area d-flex">
    <!-- Post Favourite -->
    <div class="post-favourite">
        <a href="#"><i class="bi bi-heart"></i> 10</a>
    </div>
    <!-- Post Comments -->
    <div class="post-comments">
        <a href="#"><i class="bi bi-chat"></i> 12</a>
    </div>
    <!-- Post Share -->
    <div class="post-share">
        <a href="#"><i class="bi bi-share"></i></a>
    </div>
</div>
</div>
<div class='item_info  col-6'>
</div>
<span class="cart  col-3 ">


<div class="row">


   <div class="input-group btn-group-sm col-6">


      <div data-cartvalue="._cart_value_<?= $v["id"] ?>" class="input-group-text  _cart_value_p" id="btnGroupAddon2">+</div>

      <input type="text" class="form-control _cart_value_<?= $v["id"] ?>" style="width: 30px; text-align: center;" value="1" aria-describedby="btnGroupAddon2">

      <div data-cartvalue="._cart_value_<?= $v["id"] ?>" class="input-group-text _cart_value_m" id="btnGroupAddon2">-</div>

   </div>


</div> <a class=" add_tocart" data-cartvalue="._cart_value_<?= $v["id"] ?>" data-url="<?= OptionsClass::$Path ?>cart/add/<?= $v["id"] ?>" href="#">



   اضافة الى قائمة التسوق


</a>

</span>

</div>
                    <div class="why-text ">
                        <h4 class="item_title">
                            <?= $v["name"] ?>

                        </h4>
                        <div class="price">
                                <?= $v["price"] ?>
                                ر ٫س
                </div>
                        <div class="hlight-area">
                            <?= $v["des"] ?>

                        </div>





                    </div>
                </div>
         
         
         
         
                <?= PageClass::view("comment"); ?>
         
         
            </div>

        



        </div>
    </div>

</main>




<div>
        
<div class="mod_title"> وصفات مشابهة</div>

    <?php
                        foreach (OptionsClass::$ComponentData["related"]  as $k => $v) {
                        ?>
                           <div class="">
                              <div class="products-single fix">
                                 <div class="box-img-hover">
                                    <div class="type-lb">

                                    </div>
                                    <img src="<?= OptionsClass::$UploadFloder . $v["image"] ?>" class="img-fluid" alt="Image">
                                    <div class="mask-icon">
                                       <ul>
                                          <li><a href="<?=OptionsClass::$Path?>Recipe/item/<?=$v["id"]?>" data-toggle="tooltip" data-placement="right" title="عرض"><i class="bi bi-eye"></i></a></li>
                                          <li></i></a></li>
                                          <li></li>
                                       </ul>
                                       
                                    </div>
                                 </div>
                                 <div class="why-text">
                                    <h4>
                                       <?= $v["name"] ?>
                                    </h4>

                                 </div>
                              </div>
                           </div>


<?php } ?></div>
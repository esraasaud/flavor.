<div class="all-title-box">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h2>صفحتي </h2>

            </div>
        </div>
    </div>
</div>




    <div style='padding: 18px; background: #eee; ' class="user_bar">
    <div class="container">
    <?php

global $db;
$uid =   $_SESSION["login"]["id"];
UsersComponent::getUserBlock($uid);

?>


        <table class='table'>
            <tr>
                <th> المتابعين</th>
                <th> المتابعون</th>
                <th> المشاركات</th>

            </tr>


            <tr>
                <td>
                    <?php
                    echo Count($db->getData("follow", "*", "user='$uid'"));
                    ?>
                </td>
                <td> <?php
                        echo Count($db->getData("follow", "*", "follower='$uid'"));
                        ?>
                </td>
                <td> <?php
                        echo Count($db->getData("recipes", "*", "user='$uid'"));
                        ?>
                </td>

            </tr>
        </table>




    </div>

</div>
<div class="container">
    <br />
    <br />
    <div class="row">
        <div class="col-3">
        </div>
        <div class="col-6 card">

            <br />
            <br />



            <form method="POST" enctype="multipart/form-data">

<?php

OptionsClass::$Action  = "edit";
?>
                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">  إسم </label>
                    <input type="text" name="name" value="<?= OptionsClass::getValue("name") ?>" class="form-control">
                </div>




                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">  البريد </label>
                    <input type="text" name="email" value="<?= OptionsClass::getValue("email") ?>" class="form-control">
                </div>
                <div class="mb-3">
                    <label class="form-label"> كلمة السر </label>
                    <input type="password" name="password" value="<?= OptionsClass::getValue("password") ?>" class="form-control">
                </div>








                <div class="col-12">
                    <label class="form-label"> التليفون </label>
                    <input type="text" name="phone" class="form-control" value="<?= OptionsClass::getValue("phone") ?>" aria-describedby="emailHelp">
                </div>









                <div class="mb-3">
                    <label for="formFile" class="form-label"> صورة</label>
                    <input class="form-control" type="file" name="image" id="formFile">
                </div>
                <hr />
                <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                    <button type="reset" class="btn  btn-outline-secondary ">مسح</button>
                    <button type="submit" class="btn btn-lg  btn-primary me-md-2"> إرسال</button>
                </div>

            </form>
        </div> <br />

    </div> <br />

</div> <br />
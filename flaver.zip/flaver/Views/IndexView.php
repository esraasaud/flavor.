


<!-- Start Slider -->
<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">


    <ol class="carousel-indicators">


        <?php
        $i = 0;
        foreach (OptionsClass::$ComponentData["slideshow"] as $k => $v) {
        ?>
            <li data-target="#carouselExampleIndicators" data-slide-to="<?= $i ?>" class="<?php echo ($i == 0 ? "active" : ""); ?> "></li>

        <?php $i++;
        }  ?>

    </ol>

    <div class="carousel-inner">
        <?php
        $i = 0;
        foreach (OptionsClass::$ComponentData["slideshow"] as $k => $v) {

        ?>
            <div class="carousel-item <?php echo ($i == 0 ? "active" : ""); ?> ">
                <img class="d-block w-100" alt="First slide" src="<?= OptionsClass::$UploadFloder . $v["image"] ?>" class="img-fluid" alt="Image">

                <div class="carousel-caption d-none d-md-block">
                    <div class="row">
                        <div class="col-md-12">
                            <h5 class="m-b-20"> <?= $v["name"] ?></h5>
                            <p class="m-b-40">
                                <?= $v["des"] ?>
                                <br>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        <?php

            $i++;
        }
        ?>

    </div>
    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">السابق</span>
    </a>
    
    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
        <span class="sr-only">التالى </span>

        <span class="carousel-control-next-icon" aria-hidden="true"></span>
    </a>
</div>
<!-- End Slider -->

<div class="products-box">
    <div class="container">


        <div class="row">
            <div class="col-lg-12">
                <div class="title-all text-center">
                   

<!-- about start-->
<div id="about" class="layout_padding about_section">
		<div class="container">
			<div class="row">
		        <div class="col-md-6">
		        	<div><img src="images/cupcake-img.png" style="max-width: 100%;"></div>
		        </div>
		        <div class="col-md-6">
		        	<h1 class="about_text"><strong> عن مشروعنا<span class="color"></span></strong></h1>
		        	<p class="about_taital">إن الجنون تجاه الطعام والوصفات اللذيذة عملية لا تنتهي في العالم. يريد الناس تذوق المواد الغذائية المختلفة والأطباق من مختلف المناطق في جميع أنحاء العالم. تختلف نكهة الأطباق من مكان إلى آخر ولها بعض التفرد الذي يريد الجميع تجربته. يحاول الناس تحضير الأطباق المختلفة في منازلهم والاستمتاع بمذاقها اللذيذ. تساعد تقنية اليوم الناس من حيث الطهي في مطبخهم من خلال المكونات المتوفرة لديهم.
سيساعد تطبيقنا المستخدمين على إعداد وصفات لذيذة مختلفة بخطوات سهلة حسب المكونات التي يختارونها. سيوفر مئات الوصفات حول العالم بأذواق مختلفة. أيضا ، سيكون لديه أنواع مختلفة من المأكولات 
بعد اختيار ما يجب تحضيره ، تقدم هذه التطبيقات إرشادات خطوة بخطوة لتحضير الأطباق في وقت الطهي. باتباع الإرشادات ، يمكن لأي شخص صنع الأطباق دون أي صعوبة. توفر هذه التطبيقات أيضًا الوقت اللازم لإعداد الطعام والقيمة الغذائية والمزيد. سيساعد الكثير من الأشخاص الذين يرغبون في تعلم كيفية الطهي أو يرغبون في تجربة أنواع مختلفة من الطعام أو أولئك الذين يهتمون بفن الطهي بشكل عام.
</p>
		        	
		        </div>
			</div>
		</div>
	</div>





                </div>
            </div>
        </div>

      



        <div class="row special-list col-12">
            <div class="row">


            <?php
                foreach (OptionsClass::$ComponentData["products"] as $k => $v) {
                ?>
                    <div class="col-sm-6 col-md-6 col-lg-4 col-xl-4">
                        <div class="products-single fix">
                            <div class="box-img-hover">
                                <div class="type-lb">

                                </div>
                                <img src="<?= OptionsClass::$UploadFloder . $v["image"] ?>" class="img-fluid" alt="Image">

                                <div class="mask-icon">
                                    <ul>
                                        <li><a href="<?= OptionsClass::$Path ?>products/item/<?= $v["id"] ?>" data-toggle="tooltip" data-placement="right" title="عرض"><i class="bi bi-eye"></i></a></li>
                                        <li><a    class="<?= ProductsComponent::_is_liked($v["id"]) ?  "act" : ""  ?>" href="#" onclick="_setlike(event,this)"  data-url="<?= OptionsClass::$Path ?>products/like/<?= $v["id"] ?>" 
                                        data-toggle="tooltip" data-placement="right" title="اضافة الى الإشارات المرجعية"><i class="bi bi-heart"></i></a></li>
                                        <li><a  class="<?= ProductsComponent::_is_bookmart($v["id"]) ?  "act" : ""  ?>" href="#" onclick="_setbookmark(event,this)" 
                                          data-url="<?= OptionsClass::$Path ?>products/bookmarke/<?= $v["id"] ?>" 
                                         data-toggle="tooltip" data-placement="right" title="اعجاب"><i class="bi bi-bookmark"></i></a></li>
                                    </ul>
                                    <span class="cart ">
                                        <div class="row">
                                            <div class="input-group btn-group-sm col-6">
                                                <div data-cartvalue="._cart_value_<?= $v["id"] ?>" class="input-group-text  _cart_value_p" id="btnGroupAddon2">+</div>
                                                <input type="text" class="form-control _cart_value_<?= $v["id"] ?>" style="width: 30px; text-align: center;" value="1" aria-describedby="btnGroupAddon2">
                                                <div data-cartvalue="._cart_value_<?= $v["id"] ?>" class="input-group-text _cart_value_m" id="btnGroupAddon2">-</div>
                                            </div>
                                        </div> <a class=" add_tocart" data-cartvalue="._cart_value_<?= $v["id"] ?>" data-url="<?= OptionsClass::$Path ?>cart/add/<?= $v["id"] ?>" href="#">
                                            اضافة الى قائمة التسوق
                                        </a>
                                    </span>
                                </div>
                            </div>
                            <div class="why-text">
                                <h4>
                                    <?= $v["name"] ?>
                                </h4>

                                <div class="price">
                                    <?= $v["price"] ?>
                                    ر ٫س
                                </div>

                            </div>
                        </div>
                    </div>

                <?php } ?>

            </div>
        </div>


    </div>

</div>

<!------random_recipes------------->
<div class="latest-blog">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="title-all text-center">
                    <h1>وصفات عامه</h1>
  
                </div>
            </div>





            <?php

            foreach (OptionsClass::$ComponentData["recipes"] as  $v) {

                   UI::recipeItBlock($v);
           


         
            }

            ?>
        </div>
    </div>
</div>



<style>
    .carousel-item {
        background: #000;


    }

    .carousel-item img {
        opacity: 0.5;


    }

    .item_icons a{
        color:#666
    }
    .item_icons a.act{
        color:#709028
    }


</style>
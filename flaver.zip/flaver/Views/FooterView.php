<?php





?>


<div class="footer-main">

	<div class="container">



		<div class="row">


			<?php if (isset($_SESSION["login"])) {
				$u =  $_SESSION["login"];
			?>


				<div class="col-12">

					<div class="profile">


						<div style='float:right' class="profile-image">
							<img src=" <?= OptionsClass::$UploadFloder . $u["image"] ?>" alt="">
						</div>
						<span style="padding: 16px; display: inline-block;">
							<h5 class="profile-user-name"><?= $u["name"] ?></h5>
							<a style="font-size:20px" href="<?= OptionsClass::$Path ?>users/logout/"> <i style="color:red" class="bi color-danger bi-box-arrow-left"></i></a>
							<a style=" margin:0 10px; font-size:20px;  color: #709028;" href="/flaver/users/">
								<i class="bi bi-person"></i>
							</a>

						</span>
					</div>
					<br />
					<br />
					<br />





				</div>
			<?php  } ?>


			<div class="col-lg-4 col-md-12 col-sm-12">
				<div class="footer-top-box">
					<h3>قروب تخرج 32</h3>
					<ul class="list-time">
						<li>اسراء الزهراني</li>
						<li>جود القحطاني</li>
						<li> طيف الغامدي</li>
						<li> رغد القثمي</li>
						<li> البتول المشعل</li>
					</ul>
				</div>
			</div>
			<div class="col-lg-4 col-md-12 col-sm-12">
				<div class="footer-top-box">
					<h3>للاقتراحات</h3>
					<form class="newsletter-box">
						<div class="form-group">
							<input class="" type="email" name="Email" placeholder=" البريد الاكترونى">
							<i class="fa fa-envelope"></i>
						</div>
						<button class="btn hvr-hover" type="submit">ارسال</button>
					</form>
				</div>
			</div>
			<div class="col-lg-4 col-md-12 col-sm-12">
				<div class="footer-top-box">
					<h3>التواصل الاجتماعي</h3>
					<p>لنشر موقعنا على كافة موافع التواصل الاجتماعي</p>
					<ul>
						<li><a href="#"><i class="bi bi-facebook"></i></a></li>
						<li><a href="#"><i class="bi bi-twitter"></i></a></li>
						<li><a href="#"><i class="bi bi-instagram"></i></a></li>
						<li><a href="#"><i class="bi bi-linkedin"></i></a></li>
						<li><a href="#"><i class="bi bi-whatsapp"></i></a></li>
					</ul>
				</div>
			</div>
		</div>
		<hr>

		<!-- End Footer  -->
		<!-- End copyright  -->

		<a href="#" id="back-to-top" title="Back to top" style="">↑</a>



	</div>
</div>
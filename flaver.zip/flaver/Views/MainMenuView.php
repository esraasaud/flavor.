
        
<?php
function active($u){
$r="";
    if(OptionsClass::$Component==$u){
        print  "active";
    }
    print  "";
}

?>

                <div class="collapse navbar-collapse" id="navbar-menu">
                    <ul class="nav navbar-nav ml-auto" data-in="fadeInDown" data-out="fadeOutUp">
                        <li class="nav-item <?php active("index");?>"><a class="nav-link" href="<?=OptionsClass::$Path?>">الرئيسية</a></li>
                        <li class="nav-item <?php active("users");?>"><a class="nav-link" href="<?=OptionsClass::$Path?>users/"> صفحتي</a></li>
                        <li class="dropdown ">
                            <a  href="<?=OptionsClass::$Path?>Recipe/" class="nav-link  <?php active("Recipe");?> " >الوصفات</a>
                          
                        </li>


                       
                         <li class="nav-item <?php active("bookmarke");?>  "><a class="nav-link" href="<?= OptionsClass::$Path?>bookmarke/">الإشارات المرجعية</a></li>

                         <li class="nav-item <?php active("cart");?>  "><a class="nav-link" href="<?= OptionsClass::$Path?>cart/"> عربة التسوق</a></li>
						
						<li class="nav-item"><a class="nav-link" href="<?=OptionsClass::$Path?>Recipe/add/">  شاركنا بوصفتك</a></li>
                    </ul>
                </div>
             
          
                   

  
                <?php
                ?>
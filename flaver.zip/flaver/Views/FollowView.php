
    <div class="mod_title">  
                            التواصل الاجتماعي

                            </div>



<div class="footer-top-box">
					

                           

							<p>لنشر موقعنا على كافة موافع التواصل الاجتماعي</p>
							<ul>
                                <li><a href="#"><i class="bi bi-facebook"></i></a></li>
                                <li><a href="#"><i class="bi bi-twitter"></i></a></li>
                                <li><a href="#"><i class="bi bi-instagram"></i></a></li>
                                <li><a href="#"><i class="bi bi-linkedin"></i></a></li>
                                <li><a href="#"><i class="bi bi-whatsapp"></i></a></li>
                            </ul>
						</div>
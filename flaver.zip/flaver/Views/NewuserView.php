<?php

if (isset($_GET["msg"])) {

    echo  MessageClass::success(OptionsClass::$Lang[$_GET["msg"] . "_msg"], true);
}
?>
<div class="container">
    <br />
    <br />
    <div class="row">
        <div class="col-3">
        </div>
        <div class="col-6 card">

            <br />
            <br />


            <form method="POST" sty enctype="multipart/form-data">

                <div class="row">
                    <div class="col-6">
                        <label for="exampleInputEmail1" class="form-label"> الاسم *</label>
                        <input type="text" name="name" required  value="<?= OptionsClass::getValue("name") ?>" class="form-control">
                    </div>




                    <div class="col-6">
                        <label class="form-label"> البريد الا كترونى *</label>
                        <input type="text" name="email"  required class="form-control" aria-describedby="emailHelp">
                    </div>

                    <div class="col-6">
                        <label class="form-label">  كلمة السر *</label>
                        <input type="password" placeholder="*****" required name="password" value="<?= OptionsClass::getValue("password") ?>" class="form-control">
                    </div>


                    <div class="col-6">
                        <label class="form-label">     تكرر كلمة السر  *</label>
                        <input type="password" placeholder="*****" required name="password" value="<?= OptionsClass::getValue("password") ?>" class="form-control">
                    </div>



                    <div class="col-6">
                        <label class="form-label"> التليفون </label>
                        <input type="text" name="phone" class="form-control" aria-describedby="emailHelp">
                    </div>


                    <div class="mb-3">
                        <label for="formFile" class="form-label"> صورة</label>
                        <input class="form-control" type="file" name="image" id="formFile">
                    </div>



                    <div class="mb-3">
                        <label class="form-label">العنوان </label>
                        <textarea class="form-control" name="address" rows="3"></textarea>
                    </div>

                    <hr />
                    <div class="d-grid gap-2 d-md-flex ">
                        <button type="reset" class="btn  btn-outline-secondary ">مسح</button>
                        <button type="submit" class="btn btn-lg  btn-primary me-md-2"> إرسال</button>
                    </div>
                    <a style="text-align: left;" href="<?= OptionsClass::$Path ?>users/new/"> عودة الى تسجيل دخول </a>

                </div>


            </form>

            <br />

        </div>
    </div>
</div>
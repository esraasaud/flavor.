<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <div class="lh-1">
        <h1 class="h6 mb-0 ">المنتجات</h1>
        <small><?= OptionsClass::$Lang[OptionsClass::$Action] ?></small>
    </div>


    <div class="btn-toolbar mb-2 mb-md-0">
        <a href="<?= OptionsClass::$Url["component"] ?>" type="button" class="btn btn-sm ">عودة <i class="bi bi-arrow-left"></i> </a>
    </div>
</div>



<?php

if (isset($_GET["msg"])) {

    echo  MessageClass::success(OptionsClass::$Lang[$_GET["msg"] . "_msg"], true);
}
?>
<?php if (OptionsClass::$Action  == "add" || OptionsClass::$Action  == "edit") {
?>

    <form method="POST" class="row" enctype="multipart/form-data">



        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">  إسم المنتج </label>
            <input type="text" name="name" value="<?= OptionsClass::getValue("name") ?>" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
        </div>


        <div class="mb-3">
            <label for="inputMethod" class="form-label">الطريقة </label>
            <textarea class="form-control" name="method" name="des" id="inputMethod" rows="3"><?= OptionsClass::getValue("des") ?></textarea>
        </div>


        <div class="mb-3">
            <label for="inputDes" class="form-label">المقادير </label>
            <textarea class="form-control" name="des" id="inputDes" rows="2"><?= OptionsClass::getValue("des") ?></textarea>
        </div>



        <div class="mb-3 col-4">
            <label for="selectDifficulty" class="form-label"> مستوى الصعوبة </label>


            <select name="difficulty" id="selectDifficulty" class="form-select">
                <option>مستوى الصعوبة</option>
                <option value="easy">سهل</option>
                <option value="mid">متوسط</option>
                <option value="hard">صعب</option>
            </select>
        </div>


        <div class="mb-3 col-4">
            <label for="meal" class="form-label"> الوجبة </label>


            <select id="meal" name="meal" class="form-select">
                <option> الوجبة</option>
                <option value="breakfast">فطور</option>
                <option value="lunch">غداء</option>
                <option value="dinner">عشاء</option>
                <option value="Sweetening">تحلية</option>
                <option value="Sidedishes"> اطباق جانبية</option>
            </select>
        </div>
        <div class="mb-3 col-4">
            <label for="time" class="form-label"> الوقت </label>




            <select id="time" name="time" class="form-select">
                <option> الوقت</option>
                <option value="10">اقل من 10 دقائق
                </option>
                <option value="20">اقل من 20 دقيقة
                </option>
                <option value="30"> اقل من 30 دقيقة

                </option>
                <option value="40">

                    اقل من40 دقيقة

                </option>



                <option value="50"> 50 دقيقة فاكثر</option>

            </select>
        </div>




        <div class="mb-3 col-6">
            <label for="calories" class="form-label"> السعارات الحرارية </label>
            <input type="text" name="calories" value="<?= OptionsClass::getValue("name") ?>" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
        </div>



        <div class="mb-3 col-6">
            <label for="fats" class="form-label"> الدهون </label>
            <input type="text" name="fats" value="<?= OptionsClass::getValue("name") ?>" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
        </div>



        <div class="mb-3">
            <label for="formFile" class="form-label"> صورة</label>
            <input class="form-control" type="file" name="image" id="formFile">
        </div>

        <div class="mb-3">
            <label for="formFile" class="form-label">الفيديو</label>
            <input class="form-control" type="file" name="video" id="formFile">
        </div>

        <hr />
        <div class="d-grid gap-2 d-md-flex justify-content-md-end">
            <button type="reset" class="btn  btn-outline-secondary ">مسح</button>
            <button type="submit" class="btn btn-lg  btn-primary me-md-2"> إرسال</button>
        </div>

    </form>


<?php } else { ?>



    <table class="table table-hover table-striped  table-sm">
        <tr>
        <th> المستخدم</th>

            <th>الاسم</th>
            <th> نبذة</th>
            <th>صورة</th>
            <th>
                <a href="products/add" type="button" class="btn btn-sm btn-secondary">
                    <i class="bi bi-plus"></i>
                </a>
            </th>
        </tr>
        <tbody>

            <?php
            foreach (OptionsClass::$ComponentData  as $k => $v) {
            ?>

                <tr>


                    <td> <?php

                            if ($v["user"] == "0") {
                                echo "@زائر";
                            } else {
                                global $db;
                                $us =  $db->getData("users", "*", "id='" . $v["user"] . "'");
                                if ($us  != null) {
                                    $u = $us[0]
                            ?>
                                <div class="col-12">

                                    <div class="profile">


                                        <div style='float:right' class="profile-image">
                                            <img style="height:60px;" src=" <?= OptionsClass::$UploadFloder . $u["image"] ?>" alt="">
                                        </div>
                                        <span style="padding: 16px; display: inline-block;">
                                            <h5 class="profile-user-name"><?= $u["name"] ?></h5>

                                        </span>
                                    </div>

                                </div>
                        <?php

                                } else {

                                    echo "@زائر";
                                }
                            }
                        ?>
                    </td>


                    <td> <?= $v["name"] ?></td>
                    <td> <?= $v["des"] ?></td>
                    <td> <img style="height: 80px;" src="<?= OptionsClass::$UploadFloder . $v["image"] ?>" /></td>
                    <td>
                        <div class="btn-group mb-3">
                            <a href="<?= OptionsClass::$Url["edit"] . $v["id"] ?>" type="button" class="btn btn-sm btn-outline-secondary">
                                <i class="bi bi-pencil"></i>
                                <a href="<?= OptionsClass::$Url["delete"] . $v["id"] ?>" onclick="_delete(event,this)" type="button" class="btn btn-sm btn-outline-danger">
                                    <i class="bi bi-x"></i>
                                </a>
                        </div>
                    </td>
                </tr>
            <?php
            }
            ?>
        </tbody>
    </table>
<?php
} ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <div class="lh-1">
        <h1 class="h6 mb-0 ">المنتجات</h1>
        <small><?= OptionsClass::$Lang[OptionsClass::$Action] ?></small>
    </div>


    <div class="btn-toolbar mb-2 mb-md-0">
        <a href="<?= OptionsClass::$Url["component"] ?>" type="button" class="btn btn-sm ">عودة <i class="bi bi-arrow-left"></i> </a>
    </div>
</div>



<?php

if (isset($_GET["msg"])) {

    echo  MessageClass::success(OptionsClass::$Lang[$_GET["msg"] . "_msg"], true);
}
?>
<?php if (OptionsClass::$Action  == "add" || OptionsClass::$Action  == "edit") {
if ( OptionsClass::$Action  == "edit") {

?>



<h4>
         المنتجات
      </h4>
      <div class="row">
         <table class="table table-striped">
            <?php
            global $db;


            $products =  json_decode( OptionsClass::$ComponentData["products"],true);


            foreach ( $products as $k => $c) {
               $v =  $db->getData("products", "*", "id ='$k'")[0];
            ?>
               <tr>
                  <td style="width: 150px;"> <img style='height:90px; ' src="<?= OptionsClass::$UploadFloder . $v["image"] ?>" class="img-fluid" alt="Image" /> </td>
                  <td><?= $v["name"] ?> </td>
                  <td><?=  $c ?> </td>
               </tr>
            <?php } ?>
         </table>

      </div>

      <?php } ?>



    <form method="POST" enctype="multipart/form-data">










        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label"> الاسم </label>
            <input type="text" name="name"  value="<?= OptionsClass::getValue("name") ?>" class="form-control" aria-describedby="emailHelp">
        </div>


        <div class="mb-3">
            <label class="form-label"> التليفون </label>
            <input type="text" name="phone" value="<?= OptionsClass::getValue("phone") ?>"  class="form-control" aria-describedby="emailHelp">
        </div>


        <div class="mb-3">
            <label class="form-label"> البريد اللكترونى </label>
            <input type="text" name="email" value="<?= OptionsClass::getValue("email") ?>" class="form-control" aria-describedby="emailHelp">
        </div>


        <div class="mb-3">
            <label class="form-label">العنوان </label>
            <textarea class="form-control" value="<?= OptionsClass::getValue("address") ?>"  name="address" rows="3"></textarea>
        </div>


        <div class="mb-3">
            <label class="form-label">ملاحظات </label>
            <textarea class="form-control" name="des" rows="3"></textarea>
        </div>



        <hr />
        <div class="d-grid gap-2 d-md-flex justify-content-md-end">
            <button type="reset" class="btn  btn-outline-secondary ">مسح</button>
            <button type="submit" class="btn btn-lg  btn-primary me-md-2"> إرسال</button>
        </div>

        <br />
        <br />
        <br />
        <br />1


    </form>


<?php } else { ?>



    <table class="table table-hover table-striped  table-sm">
        <tr>
            <th>الاسم</th>
            <th>البريد </th>
            <th>صورة</th>
            <th>
                <a href="products/add" type="button" class="btn btn-sm btn-secondary">
                    <i class="bi bi-plus"></i>
                </a>
            </th>
        </tr>
        <tbody>

            <?php
            foreach (OptionsClass::$ComponentData  as $k => $v) {
            ?>

                <tr>

                    <td> <?= $v["name"] ?></td>
                    <td> <?= $v["email"] ?></td>
                    <td> <img style="height: 80px;" src="<?= OptionsClass::$UploadFloder . $v["image"] ?>" /></td>
                    <td>
                        <div class="btn-group mb-3">
                            <a href="<?= OptionsClass::$Url["edit"] . $v["id"] ?>" type="button" class="btn btn-sm btn-outline-secondary">
                                <i class="bi bi-pencil"></i>
                                <a href="<?= OptionsClass::$Url["delete"] . $v["id"] ?>" onclick="_delete(event,this)" type="button" class="btn btn-sm btn-outline-danger">
                                    <i class="bi bi-x"></i>
                                </a>
                        </div>
                    </td>
                </tr>
            <?php
            }
            ?>
        </tbody>
    </table>
<?php
} ?>
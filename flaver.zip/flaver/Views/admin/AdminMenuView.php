
<?php
function active($u){
$r="";
    if(OptionsClass::$Component==$u){
        print  "active";
    }
    print  "";
}

?>

<ul class="nav flex-column">
    <li class="nav-item">
        <a class="nav-link <?php active("index");?> " aria-current="page" href="<?=OptionsClass::$Path?>admin">
        <i class="bi bi-house-fill"></i>
            الرائيسية
        </a>
    </li>





    <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
    <span>المحتوى </span>
    <a class="link-secondary" href="#" aria-label="Add a new report">
    <i class="bi bi-calendar-range"></i>
    </a>
</h6>

    <li class="nav-item">
        <a class="nav-link <?php active("slideshow");?>" href="<?=OptionsClass::$Path?>admin/slideshow">
        <i class="bi bi-file-earmark-easel"></i>
            الصور المتحركة
        </a>
    </li>




    <li class="nav-item">
        <a class="nav-link <?php active("commencts");?>" href="<?=OptionsClass::$Path?>admin/commencts">
        <i class="bi bi-chat"></i>
            التعليقات
        </a>
    </li>


    <li class="nav-item">
        <a class="nav-link <?php active("recipes");?>" href="<?=OptionsClass::$Path?>admin/recipes">
        <i class="bi bi-basket-fill"></i>
                    الوصفات
        </a>
    </li>
</ul>


<h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
    <span>عمليات </span>
    <a class="link-secondary" href="#" aria-label="Add a new report">
    <i class="bi bi-cart"></i>

    </a>


</h6>


<ul class="nav flex-column mb-2">

    <li class="nav-item">
        <a class="nav-link <?php active("commencts");?>" href="<?=OptionsClass::$Path?>admin/orders/">
        <i class="bi bi-cart"></i>
                الطلبات
        </a>
    </li>

    

    <li class="nav-item">
    <a class="nav-link <?php active("productsCategories");?>" href="<?=OptionsClass::$Path?>admin/productsCategories">
    <i class="bi bi-bag-check-fill"></i>

            تصنيف المنتجات
        </a>
    </li>


    <li class="nav-item">
    <a class="nav-link <?php active("products");?>" href="<?=OptionsClass::$Path?>admin/products">
    <i class="bi bi-bag-check-fill"></i>
            المنتجات
        </a>
    </li>
  

</ul>


<h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
    <span>الاعدادت </span>
    <a class="link-secondary" href="#" aria-label="Add a new report">
    <i class="bi bi-gear"></i>

    </a>
</h6>


<ul class="nav flex-column mb-2">
    <li class="nav-item <?php active("users");?> ">
        <a class="nav-link" href="<?=OptionsClass::$Path?>admin/users">
        <i class="bi bi-people-fill"></i>

المستخدمين 
        </a>
    </li>
    

</ul>




<div class="container">

<?php




if (isset($_GET["msg"])) {


  if ($_GET["msg"]=="login_error") {
    echo  MessageClass::error(OptionsClass::$Lang[$_GET["msg"] . "_msg"], true);

  }else{
    echo  MessageClass::success(OptionsClass::$Lang[$_GET["msg"] . "_msg"], true);



  }
}
?>
  <br />
  <br />
  <div class="row">
    <div class="col-4">
    </div>
    <div class="col-4 card">
      <br />
      <form method="POST">
        <div class="mb-3">
          <label for="exampleInputEmail1" class="form-label"> البريد الاكترونى </label>
          <input type="email" name="email" required class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
          <div id="emailHelp" class="form-text"> ضع البريد الاكترونى الخاص بك </div>
        </div>
        <div class="mb-3">
          <label for="exampleInputPassword1" class="form-label">كلمة السر </label>
          <input type="password"   name="password" required class="form-control" id="exampleInputPassword1">
          <div id="emailHelp" class="form-text"> كلمة السر لا تقل عن ٨ احروف </div>

        </div>

        <button type="submit" class="btn btn-primary float-right">تسجيل الدخول</button>
      </form>




      <br />

    </div>
  </div>
  <br />
  <br />
</div>
<?php

global  $db;
$c = OptionsClass::$ComponentData["comments"];

if (isset($_POST["comment"])) {
    $_POST["created"] =  OptionsClass::getDate();
    if ($db->insert("comments", $_POST)) {

        echo  MessageClass::success(OptionsClass::$Lang["comment_msg"], true);
    }
}
$cdata = $db->getData("comments", "*", "obj_id={$c["id"]} and obj_type='{$c["type"]}'");


?>





<div class="comeents_area border">

    <?php
    foreach ($cdata  as $i) {
    ?>

        <div class="comment item">

            <div>
                <div>



                    <?php

                    if ($i["user"] == "0") {
                        echo "@زائر";
                    } else {
                        global $db;
                        $us =  $db->getData("users", "*", "id='{$i["user"]}'");
                        if ($us  != null) {
                            $u = $us[0]
                    ?>
                            <div class="col-12">

                                <div class="profile">


                                    <div style='float:right' class="profile-image">
                                        <img style="height:60px;" src=" <?= OptionsClass::$UploadFloder . $u["image"] ?>" alt="">
                                    </div>
                                    <span style="padding: 16px; display: inline-block;">
                                        <h5 class="profile-user-name"><?= $u["name"] ?></h5>

                                    </span>
                                </div>


                        <?php

                        }else{

                            echo "@زائر";
                        }
                    }
                        ?>



                            </div>





                            <?= $i["comment"] ?>

                            <div class="item_info txet-left">
                                تم النشر فى

                                <?= OptionsClass::viewDate($i["created"]) ?>
                            </div>
                            <hr />

                </div>

            </div>


        <?php } ?>
        <form method="POST" enctype="multipart/form-data">


            <?php if (isset($_SESSION["login"])) {
                $u =  $_SESSION["login"];
            ?>
                <div class="col-12">

                    <div class="profile">


                        <div style='float:right' class="profile-image">
                            <img style="height:60px;" src=" <?= OptionsClass::$UploadFloder . $u["image"] ?>" alt="">
                        </div>
                        <span style="padding: 16px; display: inline-block;">
                            <h5 class="profile-user-name"><?= $u["name"] ?></h5>

                        </span>
                    </div>
                    <input type="hidden" name="user" value="<?= $u["id"] ?>" />

                <?php } else {

                ?>
                    <input type="hidden" name="user" value="0" />


                <?php } ?>

                <br />

                <input type="hidden" name="obj_id" value="<?= $c["id"] ?>" />
                <input type="hidden" name="obj_type" value="<?= $c["type"] ?>" />

                <div class="mb-3">
                    <label for="txtcomment" class="form-label">  نبذة </label>
                    <textarea class="form-control" name="comment" id="txtcomment" rows="3"><?= OptionsClass::getValue("des") ?></textarea>
                </div>


                <hr />
                <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                    <button type="submit" class="btn   btn-hover">
                        اترك تعليقاً
                    </button>
                </div>
        </form>
        </div>
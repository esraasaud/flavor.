<?php

$v = OptionsClass::$ComponentData["data"];
$r = OptionsClass::$ComponentData["related"];
OptionsClass::$ComponentData["comments"] = ["id" => $v["id"], "type" => "recipe"];
?>

<div class="all-title-box">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h2>



                    <?= $v["name"] ?>
                </h2>

            </div>
        </div>
    </div>
</div>



<?php

if (isset($_GET["msg"])) {

    echo  MessageClass::success(OptionsClass::$Lang[$_GET["msg"] . "_msg"], true);
}
?>







<main class='main'>



    <div class="container">

        <div class="row">

            <div class="col-sm-4 col-4">
                <?= PageClass::view("Follow"); ?>
                <br />
                <br />
                <br />
                <br />
                <?= PageClass::view("Related"); ?>


            </div>


            <div class="col-sm-8 col-md-8 col-8">

                <div style="padding:25px;">
                    <img style="border-radius: 25px; ;" src="<?= OptionsClass::$UploadFloder . $v["image"] ?>" class="img-fluid" alt="Image">
                    <div class="item_icons">
                        <ul>
                            <li><a class="<?= RecipeComponent::_is_liked($v["id"]) ?  "act" : ""  ?>" href="#" onclick="_setlike(event,this)" data-url="<?= OptionsClass::$Path ?>Recipe/like/<?= $v["id"] ?>"><i class="bi bi-heart"></i></a></li>
                            <li> <a class="<?= RecipeComponent::_is_bookmart($v["id"]) ?  "act" : ""  ?>" href="#" onclick="_setbookmark(event,this)" data-url="<?= OptionsClass::$Path ?>Recipe/bookmarke/<?= $v["id"] ?>"> <i class="bi bi-bookmark"></i></a></li>
                            <li><a href="#" data-toggle="tooltip" data-placement="right" title="اعجاب"><i class="bi bi-facebook"></i></a></li>
                            <li><a href="#" data-toggle="tooltip" data-placement="right" title="اعجاب"><i class="bi bi-twitter"></i></a></li>


                        </ul>
                    </div>

                    <div class='item_info'>



                        <div class="post-author-date-area d-flex">
                            <!-- Post Author -->
                            <div class="post-author">
                                <a href="#"> زائر</a>
                            </div>
                            <!-- Post Date -->
                            <div class="post-date ">
                                <?= OptionsClass::viewDate($v["created"]) ?>
                            </div>
                        </div>


                       




                    <div class="why-text ">
                        <h4 class="item_title">
                            <?= $v["name"] ?>

                        </h4>
                        <div class='row'>
                            <div class="hlight-area  col-6">
                                <b> مستوى الصعوبة : </b> <?= OptionsClass::$Lang["difficulty"][$v["difficulty"]] ?>
                            </div>
                            <div class="hlight-area col-6">
                                <b> الوجبة : </b> <?= OptionsClass::$Lang["male"][$v["meal"]] ?>
                            </div>
                            <div class="hlight-area col-6">
                                <b> الوقت : </b>
                                <?= OptionsClass::$Lang["time"][$v["time"]] ?>
                            </div>

                            <div class="hlight-area col-6">
                                <b> الدهون : </b> <?= $v["fats"] ?>
                            </div>
                            <div class="hlight-area col-6">
                                <b> السعرات الحرارية </b>
                                <?= $v["calories"] ?>
                            </div>
                            <div class="hlight-area col-12">
                                <?php
                                $d = explode(",",    $v["des"]);
                                echo '<ol>';
                                foreach ($d as $i) {
                                    echo '<li> # ' . $i . '</li>';
                                }
                                echo '</ol>';
                                ?>
                            </div>

                        </div>

                        <div class=" item_des">
                            <?= $v["method"] ?>
                        </div>
                    </div>
                </div>
                <?= PageClass::view("comment"); ?>
            </div>
        </div>
    </div>

</main>
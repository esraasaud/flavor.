<?php


function _chekFilter($name, $value)
{

   if (isset(OptionsClass::$ComponentData["filter"][$name])) {
      if (OptionsClass::$ComponentData["filter"][$name] == $value) {

         return " active ";
      } else {
         return "";
      }
   } else {


      return "";
   }
}
?>


<div class="all-title-box">
   <div class="container">
      <div class="row">
         <div class="col-lg-12">
            <h2>البحث</h2>

         </div>
      </div>
   </div>
</div>



<?php

if (isset($_GET["msg"])) {

   echo  MessageClass::success(OptionsClass::$Lang[$_GET["msg"] . "_msg"], true);
}

?>

<main class='main'>
<div class="container">
   <div class="row">

      <div class="col-xl-3 col-lg-3 col-sm-12 col-xs-12 sidebar-shop-left">
         <div class="product-categori">
            <div class="search-product">
               <form action="#">
                  <input class="form-control" placeholder="ابحث هنا ..." type="text">
                  <button type="submit"> <i class="bi bi-search"></i> </button>
               </form>
            </div>
            <div class="filter-sidebar-left">
               <div class="title-left">
                  <h3>التصنيفات</h3>
               </div>



               <div class="list-group list-group-collapse list-group-sm list-group-tree" id="list-group-men" data-children=".sub-men">
                  <div class="list-group-collapse sub-men">
                     <a class="list-group-item list-group-item-action" href="#sub-men1" data-toggle="collapse" aria-expanded="true" aria-controls="sub-men1"> الوجبة
                     </a>
                     <div class="collapse show data_filter" data-filter="cat_id" id="sub-men1" data-parent="#list-group-men">
                        <div class="list-group">

                           <?php
                           foreach (OptionsClass::$ComponentData["products_categories"]  as $k => $v) {
                           ?>
                              <a href="#" data-name="cat_id" data-value="<?= $v["id"] ?>" class="list-group-item list-group-item-action <?= _chekFilter("cat_id",  $v["id"]) ?> "><?= $v["name"] ?> <small class="text-muted"></small></a>

                           <?php  } ?>
                        </div>
                     </div>
                  </div>

               </div>

            </div>
         </div>
      </div>
      <div class="col-xl-9 col-lg-9 col-sm-12 col-xs-12 shop-content-right">
         <div class="right-product-box">
            <div class="product-item-filter row">


               <div class="col-7 col-sm-7 text-center text-sm-left">
               </div>

               <div class="col-3 col-sm-3 text-center text-sm-left">
                  <div class="toolbar-sorter-right">

                     <select id="basic" class="selectpicker show-tick form-control">
                        <option data-display="Select">الاحدث</option>
                        <option value="1">الأشهر</option>
                        <option value="2">الاقل مكونات</option>
                        <option value="3">الاسرع في التحضير</option>

                     </select>

                  </div>

               </div>



               <div class="col-2 col-sm-2 text-center text-sm-right">
                  <ul class="nav nav-tabs ml-auto">
                     <li>
                        <a class="nav-link active" href="#grid-view" data-toggle="tab"> <i class="bi bi-list-ul"></i> </a>
                     </li>
                     <li>
                        <a class="nav-link" href="#list-view" data-toggle="tab"> <i class="bi bi-grid-fill"></i> </a>
                     </li>
                  </ul>
               </div>





            </div>




            <div class="product-categorie-box">
               <div class="tab-content">
                  <div role="tabpanel" class="tab-pane fade show active" id="grid-view">
                     <div class="row">

                        <?php
                        foreach (OptionsClass::$ComponentData["data"] as $k => $v) {
                        ?>
                           <div class="col-sm-6 col-md-6 col-lg-4 col-xl-4">
                              <div class="products-single fix">
                                 <div class="box-img-hover">
                                    <div class="type-lb">

                                    </div>
                                    <img src="<?= OptionsClass::$UploadFloder . $v["image"] ?>" class="img-fluid" alt="Image">
                                    <div class="mask-icon">
                                       <ul>
                                          <li><a href="<?= OptionsClass::$Path ?>products/item/<?= $v["id"] ?>" data-toggle="tooltip" data-placement="right" title="عرض"><i class="bi bi-eye"></i></a></li>
                                          <li><a href="#" data-toggle="tooltip" data-placement="right" title="اضافة الى الإشارات المرجعية"><i class="bi bi-bookmark"></i></a></li>
                                          <li><a href="#" data-toggle="tooltip" data-placement="right" title="اعجاب"><i class="bi bi-heart"></i></a></li>



                                            <li><a    class="<?= ProductsComponent::_is_liked($v["id"]) ?  "act" : ""  ?>" href="#" onclick="_setlike(event,this)"  data-url="<?= OptionsClass::$Path ?>products/like/<?= $v["id"] ?>" 
                                        data-toggle="tooltip" data-placement="right" title="اضافة الى الإشارات المرجعية"><i class="bi bi-heart"></i></a></li>
                                        <li><a  class="<?= ProductsComponent::_is_bookmart($v["id"]) ?  "act" : ""  ?>" href="#" onclick="_setbookmark(event,this)" 
                                          data-url="<?= OptionsClass::$Path ?>products/bookmarke/<?= $v["id"] ?>" 
                                         data-toggle="tooltip" data-placement="right" title="اعجاب"><i class="bi bi-bookmark"></i></a></li>
                              

                                          
                                       </ul>
                                       <span class="cart ">


                                          <div class="row">


                                             <div class="input-group btn-group-sm col-6">


                                                <div data-cartvalue="._cart_value_<?= $v["id"] ?>" class="input-group-text  _cart_value_p" id="btnGroupAddon2">+</div>

                                                <input type="text" class="form-control _cart_value_<?= $v["id"] ?>" style="width: 30px; text-align: center;" value="1" aria-describedby="btnGroupAddon2">

                                                <div data-cartvalue="._cart_value_<?= $v["id"] ?>" class="input-group-text _cart_value_m" id="btnGroupAddon2">-</div>

                                             </div>


                                          </div> <a class=" add_tocart" data-cartvalue="._cart_value_<?= $v["id"] ?>" data-url="<?= OptionsClass::$Path ?>cart/add/<?= $v["id"] ?>" href="#">



                                             اضافة الى قائمة التسوق


                                          </a>

                                       </span>
                                    </div>
                                 </div>
                                 <div class="why-text">
                                    <h4>
                                       <?= $v["name"] ?>
                                    </h4>
                                    <div class="price">
                                       <?= $v["price"] ?>
                                       ر ٫س
                                    </div>
                                 </div>
                              </div>
                           </div>

                        <?php } ?>


                     </div>
                  </div>


               </div>
            </div>
         </div>
      </div>

      </div>

   </div>

</main>


<script>
   document.querySelectorAll(".data_filter a").forEach(function(obj) {
      obj.onclick = function(event) {
         event.preventDefault();
         var p = obj.parentNode.parentNode;
         p.querySelectorAll("a").forEach(function(a) {
            a.classList.remove("active");
         })
         obj.classList.add("active");
         _function_get_filter();

      };


   })


   function _function_get_filter() {
      var f = "";



      document.querySelectorAll("a.active").forEach(function(a) {

         if (a.dataset.value != null) {
            f += ";" + a.dataset.name +
               "," + a.dataset.value;
         }

      })

      if (f != "") {
         window.location = "?filter=" + f;

      }


   }
</script>
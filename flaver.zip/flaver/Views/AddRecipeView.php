<haed>
<title> </title>
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Amiri:ital@1&display=swap" rel="stylesheet">
</head>
<div class="all-title-box">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h2>شاركنا بوصفتك</h2>

            </div>
        </div>
    </div>
</div>

<?php


if (isset($_GET["msg"])) {

    echo  MessageClass::success(OptionsClass::$Lang[$_GET["msg"] . "_msg"], true);
}
?>
<main class='main'>


    <div class="contact-box-main">
        <div class="container">
            <div class="row">

                <form id="contactForm" class="row" method="POST" enctype="multipart/form-data">




                    <?php if (isset($_SESSION["login"])) {
                        $u =  $_SESSION["login"];
                    ?>
                        <div class="col-12">

                            <div class="profile">


                                <div style='float:right' class="profile-image">
                                    <img style="height:60px;" src=" <?= OptionsClass::$UploadFloder . $u["image"] ?>" alt="">
                                </div>
                                <span style="padding: 16px; display: inline-block;">
                                    <h5 class="profile-user-name"><?= $u["name"] ?></h5>

                                </span>
                            </div>


                            <input type="hidden" name="user" value="<?= $u["id"] ?>" />
                        </div>
                    <?php } else {

                    ?>
                        <input type="hidden" name="user" value="0" />


                    <?php } ?>

                    <br />

                    <div class="col-lg-8 col-sm-12">
                        <div class="contact-form-right">
                            <div class="row">

                                <h2>شاركنا بوصفتك</h2>
                                <p> شاركنا بوصفتك في موقعنا مع الوصف والمقادير ومشاركتنا بصور ومقاطع للوصفة ايضاً</p>



                                <div class="mb-3">
                                    <label for="inputName" class="form-label">  إسم المنتج </label>
                                    <input type="text" name="name" value="<?= OptionsClass::getValue("name") ?>" class="form-control" id="inputName" aria-describedby="emailHelp" required>
                                </div>



                                <div class="mb-3">
                                    <label for="inputMethod" class="form-label">الطريقة </label>
                                    <textarea class="form-control" name="method" name="des" id="inputMethod" rows="3" required><?= OptionsClass::getValue("des") ?></textarea>
                                </div>


                                <div class="mb-3">
                                    <label for="inputDes" class="form-label">المقادير </label>
                                    <textarea class="form-control" name="des" id="inputDes" rows="2" required><?= OptionsClass::getValue("des") ?></textarea>
                                </div>





                                <div class="mb-3 col-4">
                                    <label for="selectDifficulty" class="form-label"> مستوى الصعوبة </label>


                                    <select name="difficulty" id="selectDifficulty" class="form-select" required>
                                        <option>مستوى الصعوبة</option>
                                        <option value="easy">سهل</option>
                                        <option value="mid">متوسط</option>
                                        <option value="hard">صعب</option>
                                    </select>
                                </div>


                                <div class="mb-3 col-4">
                                    <label for="meal" class="form-label"> الوجبة </label>


                                    <select id="meal" name="meal" class="form-select" required>
                                        <option> الوجبة</option>
                                        <option value="breakfast">فطور</option>
                                        <option value="lunch">غداء</option>
                                        <option value="dinner">عشاء</option>
                                        <option value="Sweetening">تحلية</option>
                                        <option value="Sidedishes"> اطباق جانبية</option>
                                    </select>
                                </div>
                                <div class="mb-3 col-4">
                                    <label for="time" class="form-label"> الوقت </label>




                                    <select id="time" name="time" class="form-select" required>
                                        <option> الوقت</option>
                                        <option value="10">اقل من 10 دقائق
                                        </option>
                                        <option value="20">اقل من 20 دقيقة
                                        </option>
                                        <option value="30"> اقل من 30 دقيقة

                                        </option>
                                        <option value="40">

                                            اقل من40 دقيقة

                                        </option>



                                        <option value="50"> 50 دقيقة فاكثر</option>

                                    </select>
                                </div>




                                <div class="mb-3 col-6">
                                    <label for="calories" class="form-label">  السعرات الحرارية  </label>
                                    <input type="text" name="calories" value="<?= OptionsClass::getValue("calories") ?>" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                                </div>



                                <div class="mb-3 col-6">
                                    <label for="fats" class="form-label"> الدهون </label>
                                    <input type="text" name="fats" value="<?= OptionsClass::getValue("fats") ?>" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                                </div>




                                <hr />
                                <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                    <button type="reset" class="btn  btn-outline-secondary ">مسح</button>
                                    <button type="submit" class="btn btn-lg  btn-primary me-md-2"> إرسال</button>
                                </div>


                            </div>
                        </div>


                    </div>

                    <div class="col-lg-4 col-sm-12">
                        <br />
                        <br />
                        <br />
                        <br />
                        <div class="contact-info-left">
                           

                            <div class="mb-3">
                                <label for="formFile" class="form-label"> صورة</label>
                                <input class="form-control" type="file" name="image" id="formFile">
                            </div>

                        </div>
                    </div>






            </div>


            </form>
        </div>
    </div>
    </div>
</main>
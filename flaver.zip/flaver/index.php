<?php
session_start();
error_reporting(E_ALL); 
ini_set('display_errors', 0);
require_once __DIR__."/utilities/Message.php";
require_once "utilities/DB.php";
require_once "utilities/Options.php";
require_once "utilities/Page.php";
require_once "utilities/dataui.php";




$path_split = PageClass::url();

if ($path_split[0]!="admin"){
require_once "Components/RecipeComponent.php";
require_once "Components/ProductsComponent.php";
require_once "Components/UsersComponent.php";
}




$db = new DBClass();


if ($path_split[0]=="admin"){
    OptionsClass::$Area="admin";
    PageClass::updateUrl();
    require_once "style/admin.php";


 }else if ($path_split[0]=="404"){
    require_once "style/404.php";

}else{
    OptionsClass::$Area="";
    PageClass::updateUrl();

    require_once "style/index.php";
}



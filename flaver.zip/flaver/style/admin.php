<!doctype html>
<html lang="ar" dir="rtl">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href="<?= OptionsClass::$Path ?>style/i/bootstrap-5.0.0-beta2-dist/css/bootstrap.rtl.min.css" rel="stylesheet" integrity="sha384-4dNpRvNX0c/TdYEbYup8qbjvjaMrgUPh+g4I03CnNtANuv+VAvPL6LqdwzZKV38G" crossorigin="anonymous">
    <script src="<?= OptionsClass::$Path ?>style/i/bootstrap-5.0.0-beta2-dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script>
    <link href="<?= OptionsClass::$Path ?>style/i/bootstrap-5.0.0-beta2-dist/bootstrap-icons-1.4.0/bootstrap-icons.css" rel="stylesheet">
    <link href="<?= OptionsClass::$Path ?>style/admin.css" rel="stylesheet">
    <link href="<?= OptionsClass::$Path ?>style/admin.css" rel="stylesheet">

    <script src="<?= OptionsClass::$Path ?>style/script.js"></script>



    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200;300;600;700;900&display=swap" rel="stylesheet">

</head>


<body>


    <header class="navbar navbar-dark sticky-top bg-dark flex-md-nowrap p-0 shadow">
        <a class="navbar-brand col-md-3 col-lg-2 me-0 px-3" href="#">Flaver </a>
        <button class="navbar-toggler position-absolute d-md-none collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#sidebarMenu" aria-controls="sidebarMenu" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <input class="form-control form-control-dark w-100" type="text" placeholder="Search" aria-label="Search">
        <ul class="navbar-nav px-3">
            <li class="nav-item text-nowrap">
                <a class="nav-link" href="<?= OptionsClass::$Path ?>users/logout/"> تسجيل خروج</a>
            </li>
        </ul>
    </header>

    <div class="container-fluid">


        <div class="row">



            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">

                <?= PageClass::main(); ?>
            </main>

            <?php 
            
            
            if (isset($_SESSION["login"]) &&trim($_SESSION["login"]["type"])  == "admin") {
                $u =  $_SESSION["login"];
            ?>

                <nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
                    <div class="position-sticky pt-3">
                        <?= PageClass::module("AdminMenu"); ?>
                        </ul>

                </nav>
            <?php  } else {

            ?>


                <?= PageClass::view("Login"); ?>


            <?php

            }
            ?>
            <br>
</body>

</html>
function _setbookmark(ev, th) {
    ev.preventDefault();
    var url = th.dataset.url;

    ajax(url, function(o) {
        if (th.classList.contains("act")) {
            th.classList.remove("act");
        } else {
            th.classList.add("act");

        }
    })
}

function _setlike(ev, th) {
    ev.preventDefault();
    var url = th.dataset.url;
    ajax(url, function(o) {
        if (th.classList.contains("act")) {
            th.classList.remove("act");
        } else {
            th.classList.add("act");

        }
    })
}






function _delete(evt, e) {
    evt.preventDefault();

    if (confirm(" هل تريد حذف هذا العنصر")) {
        window.location = e.getAttribute("href");
    }
}


function ajax(url, f) {
    $.post(url, f)
}
$(function() {


    $('.carousel').carousel();

    $('.add_tocart').on("click", function(e) {
        var v = $(this).data("cartvalue");
        var u = $(this).data("url") + "/" +
            $(v).val();
        ajax(u, function(o) {
            alert("تم إضاتفة المنتج الى سلة المشتريات شكرا لك .")
        })

    });




    $('._cart_value_p').on("click", function(e) {
        var v = $(this).data("cartvalue");
        console.log(v);

        var e = $(v);
        e.val(parseInt(e.val()) + 1);

    });
    $('._cart_value_m').on("click", function(e) {
        var v = $(this).data("cartvalue");
        var e = $(v);
        e.val(parseInt(e.val()) - 1);
        if (e.val() < 1) {
            e.val("1")

        }

    });
});
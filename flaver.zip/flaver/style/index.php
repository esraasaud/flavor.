<!doctype html>
<html lang="ar" dir="rtl">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href="<?= OptionsClass::$Path ?>style/i/bootstrap-5.0.0-beta2-dist/css/bootstrap.rtl.min.css" rel="stylesheet" integrity="sha384-4dNpRvNX0c/TdYEbYup8qbjvjaMrgUPh+g4I03CnNtANuv+VAvPL6LqdwzZKV38G" crossorigin="anonymous">
    <script src="<?= OptionsClass::$Path ?>style/i/bootstrap-5.0.0-beta2-dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
    

    <link href="<?= OptionsClass::$Path ?>style/i/bootstrap-5.0.0-beta2-dist/bootstrap-icons-1.4.0/bootstrap-icons.css" rel="stylesheet">
    <link href="<?= OptionsClass::$Path ?>style/admin.css" rel="stylesheet">
    <link href="<?= OptionsClass::$Path ?>style/style.css" rel="stylesheet">
  
    
    <script src="<?= OptionsClass::$Path ?>style/script.js"></script>
    
   


    <link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Amiri:ital@1&display=swap" rel="stylesheet">

    <link href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Amiri:ital@1&display=swap" rel="stylesheet">

    <script>
        
    </script>

</head>




<body>

    <header class="main-header">
        <nav class="navbar navbar-expand-lg navbar-light bg-light navbar-default bootsnav">
            <div class="container">

                <div class="col-2">

                    <img src="<?= OptionsClass::$Path ?>style/images/logo.png" />
                </div>

                <div class="col-9">
                    <?= PageClass::module("mainMenu"); ?>
                </div>

                
            </div>
        </nav>
    </header>


    




    <?= PageClass::main(); ?>



    <footer class="footer-main">
        <?= PageClass::module("Footer"); ?>
    </footer>


</body>

</html>

<style>




</style>
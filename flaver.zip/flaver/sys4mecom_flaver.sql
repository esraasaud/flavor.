-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: 29 مارس 2021 الساعة 01:42
-- إصدار الخادم: 10.3.28-MariaDB
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sys4mecom_flaver`
--

-- --------------------------------------------------------

--
-- بنية الجدول `bookmarkes`
--

CREATE TABLE `bookmarkes` (
  `id` int(11) NOT NULL,
  `user` varchar(255) NOT NULL,
  `obj_type` varchar(255) NOT NULL,
  `obj_id` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- إرجاع أو استيراد بيانات الجدول `bookmarkes`
--

INSERT INTO `bookmarkes` (`id`, `user`, `obj_type`, `obj_id`) VALUES
(13, '3', 'recipe', '1'),
(22, '5', 'product', '46'),
(23, '5', 'product', '33'),
(25, '5', 'product', '45'),
(27, '9', 'recipe', '1'),
(28, '11', 'recipe_cart', '3'),
(35, '11', 'recipe_cart', '8'),
(36, '11', 'recipe', '4'),
(37, '11', 'recipe_cart', '9'),
(38, '11', 'recipe_cart', '7'),
(39, '11', 'recipe_cart', '2'),
(40, '12', 'recipe_cart', '7'),
(41, '8', 'recipe_cart', '1'),
(42, '12', 'recipe', '1'),
(43, '8', 'recipe_cart', '6'),
(44, '12', 'product', '33'),
(45, '13', 'recipe_cart', '6'),
(46, '13', 'recipe', '1'),
(47, '13', 'recipe_cart', '7'),
(48, '13', 'recipe_cart', '10'),
(50, '13', 'product', '33'),
(51, '15', 'recipe', '7'),
(52, '15', 'product', '33'),
(54, '15', 'recipe_cart', '12'),
(55, '15', 'recipe_cart', '10');

-- --------------------------------------------------------

--
-- بنية الجدول `cartcheck`
--

CREATE TABLE `cartcheck` (
  `id` int(11) NOT NULL,
  `user` varchar(255) NOT NULL,
  `obj_type` text NOT NULL,
  `obj_id` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- إرجاع أو استيراد بيانات الجدول `cartcheck`
--

INSERT INTO `cartcheck` (`id`, `user`, `obj_type`, `obj_id`) VALUES
(6, '11', '', '8'),
(7, '11', 'd', '8'),
(8, '11', 'sdasdasd', '8'),
(11, '11', ' مقايرد وصفة جديدة 3', '9'),
(12, '11', 'مقايرد وصفة جديدة ١', '9'),
(13, '11', 'tea water', '7'),
(20, '15', 'ماء', '12'),
(21, '15', ' قهوة', '12');

-- --------------------------------------------------------

--
-- بنية الجدول `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `obj_type` varchar(255) NOT NULL,
  `obj_id` int(11) NOT NULL,
  `comment` text NOT NULL,
  `user` varchar(255) NOT NULL,
  `created` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- إرجاع أو استيراد بيانات الجدول `comments`
--

INSERT INTO `comments` (`id`, `obj_type`, `obj_id`, `comment`, `user`, `created`) VALUES
(8, 'recipe', 3, 'dfsdfsdf', 'محمد عبد الله ', '2021-03-21 21:54:04'),
(9, 'recipe', 3, 'sdfsdfsdf', 'محمد عبد الله ', '2021-03-21 21:54:21'),
(10, 'recipe', 3, 'sdfsdfsdf', '5', '2021-03-21 21:54:32'),
(11, 'recipe', 3, 'ffffffff', '5', '2021-03-21 21:58:40'),
(12, 'recipe', 4, 'fsdf asdasasdasd', '5', '2021-03-21 23:20:23'),
(13, 'recipe', 4, 'dasdasd', '0', '2021-03-21 23:20:47'),
(14, 'recipe', 4, 'جيد', '3', '2021-03-21 23:24:44'),
(15, 'recipe', 4, 'شسيشسيشسيشسي', '0', '2021-03-21 23:25:11'),
(16, 'products', 33, '77777777', '6', '2021-03-21 23:31:57'),
(17, 'recipe', 6, 'thank you', '8', '2021-03-24 12:07:29');

-- --------------------------------------------------------

--
-- بنية الجدول `follow`
--

CREATE TABLE `follow` (
  `id` int(11) NOT NULL,
  `user` int(11) NOT NULL,
  `follower` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- إرجاع أو استيراد بيانات الجدول `follow`
--

INSERT INTO `follow` (`id`, `user`, `follower`) VALUES
(4, 5, 5),
(6, 3, 3),
(7, 5, 3),
(9, 8, 5),
(10, 8, 8),
(12, 11, 3),
(15, 13, 5),
(16, 13, 8),
(17, 15, 8),
(18, 15, 5);

-- --------------------------------------------------------

--
-- بنية الجدول `likes`
--

CREATE TABLE `likes` (
  `id` int(11) NOT NULL,
  `obj_id` varchar(255) NOT NULL,
  `obj_type` varchar(255) NOT NULL,
  `user` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- إرجاع أو استيراد بيانات الجدول `likes`
--

INSERT INTO `likes` (`id`, `obj_id`, `obj_type`, `user`) VALUES
(50, '46', 'product ', '5'),
(51, '1', 'recipe ', '3'),
(54, '2', 'recipe ', '5'),
(60, '45', 'product ', '5'),
(62, '2', 'recipe ', '9'),
(63, '3', 'recipe ', '11'),
(64, '33', 'product ', '8'),
(65, '6', 'recipe ', '13');

-- --------------------------------------------------------

--
-- بنية الجدول `orders`
--

CREATE TABLE `orders` (
  `name` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `des` text DEFAULT NULL,
  `id` int(11) NOT NULL,
  `user` int(11) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `products` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- إرجاع أو استيراد بيانات الجدول `orders`
--

INSERT INTO `orders` (`name`, `image`, `des`, `id`, `user`, `address`, `email`, `phone`, `products`) VALUES
('asdas', NULL, 'asd', 3, NULL, 'dasd', 'البريد اللكتasdasرونى', 'الdasdasdتليفون', '{\"33\":\"6\",\"45\":\"5\",\"46\":\"4\",\"47\":\"2\"}'),
(' حسام احمد22', NULL, 'sdasd', 5, NULL, 'asda', 'aa222a@aaa.com', '45222645564', '{\"47\":\"6\",\"48\":\"5\",\"45\":\"4\",\"33\":\"3\"}'),
(' حسام احمد22', NULL, 'sdasd', 6, NULL, 'asda', 'aa222a@aaa.com', '45222645564', 'null');

-- --------------------------------------------------------

--
-- بنية الجدول `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `des` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `cat_id` int(11) NOT NULL,
  `price` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- إرجاع أو استيراد بيانات الجدول `products`
--

INSERT INTO `products` (`id`, `name`, `des`, `image`, `cat_id`, `price`) VALUES
(33, 'طماطم', 'طماطم جيدية طماطم جيدية طماطم جيدية طماطم جيدية طماطم جيدية ', '605759c740834.jpg', 1, '5'),
(45, 'فلفل', 'شسيشسيسش', '60575b724968d.jpg', 1, '6'),
(46, 'جزر', 'شسيشسيسش', '60575b9c23f85.jpg', 1, '3'),
(47, 'حبوب', 'حبوب ١حبوب ١حبوب ١حبوب ١حبوب ١حبوب ١حبوب ١حبوب ١', '60575beb568d6.jpg', 2, '2'),
(48, 'ليمون', 'حبوب ١حبوب ١حبوب ١حبوب ١حبوب ١حبوب ١حبوب ١حبوب ١', '60575c0caf6a9.jpg', 3, '2');

-- --------------------------------------------------------

--
-- بنية الجدول `products_categories`
--

CREATE TABLE `products_categories` (
  `name` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `des` text DEFAULT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- إرجاع أو استيراد بيانات الجدول `products_categories`
--

INSERT INTO `products_categories` (`name`, `image`, `des`, `id`) VALUES
('خضروات', NULL, '', 1),
('حبوب', NULL, '', 2),
('فاكهة', NULL, '', 3),
('عسل', NULL, '', 4),
('مخبازات', NULL, 'سيشسيشسي', 5),
('مخبازات', NULL, 'سيشسيشسي', 6);

-- --------------------------------------------------------

--
-- بنية الجدول `recipes`
--

CREATE TABLE `recipes` (
  `name` varchar(255) NOT NULL,
  `method` text NOT NULL,
  `des` text DEFAULT NULL,
  `difficulty` varchar(255) DEFAULT NULL,
  `meal` varchar(255) DEFAULT NULL,
  `calories` varchar(255) DEFAULT NULL,
  `fats` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `video` varchar(255) DEFAULT NULL,
  `id` int(11) NOT NULL,
  `time` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `user` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- إرجاع أو استيراد بيانات الجدول `recipes`
--

INSERT INTO `recipes` (`name`, `method`, `des`, `difficulty`, `meal`, `calories`, `fats`, `image`, `video`, `id`, `time`, `created`, `user`) VALUES
('الصوفه الثانية ', 'الصوفه الثانية الصوفه الثانية الصوفه الثانية الصوفه الثانية الصوفه الثانية الصوفه الثانية الصوفه الثانية ', 'المقادير', 'مستوى الصعوبة', 'الوقت', '', '', '6055d9f2f172e.jpg', '6055d9f2f172e.jpg', 1, '40', '2021-03-09 16:51:39', 3),
(' إسم المنتج', 'الطريقة', 'المقادير', 'مستوى الصعوبة', 'الوقت', '', '', '6055d9f2f172e.jpg', '6055d9f2f172e.jpg', 2, '10', '2021-03-03 16:51:45', 5),
('الصوفة الاولى ', 'الصوفة الاولى  الصوفة الاولى الصوفة الاولى الصوفة الاولى الصوفة الاولى الصوفة الاولى الصوفة الاولى الصوفة الاولى ', 'المقادير', 'easy', '10', 'السعارات الحرارية', 'الدهون', '6055d9f2f172e.jpg', '6055d9f2f172e.jpg', 3, '10', '2021-03-20 16:51:47', 3),
('عمل شاى', 'مياء شاى مياء شاى مياء شاى مياء شاى ', 'مياء شاى مياء شاى مياء شاى مياء شاى ', 'easy', 'lunch', 'عمل شاى', 'عمل شاى', '6057c496a2be0.jpg', '6057c496a2cd5.jpg', 4, '10', NULL, 3),
('coffee', 'add 1 spone of coffee \r\nadd half spone sugar \r\nand add milk ', 'coffee\r\nsugar\r\nmilk', 'easy', 'breakfast', '47', '8', NULL, '605b28f26f59a.jpg', 6, '10', NULL, 8),
('tea', 'put tea \r\nand hot water', 'tea \r\nwater', 'easy', 'lunch', '47', '', NULL, NULL, 7, '20', NULL, 8),
('asdasd', 'sadddd', 'sdasdasd,asdasd,asdasd,asda,d', 'easy', 'breakfast', '', '', '605c7e2450c22.jpg', '605c7e2450c81.jpg', 8, '10', NULL, 0),
('وصفة جديدة', 'وصفة جديدة وصفة جديدة وصفة جديدة ', 'مقايرد وصفة جديدة ١ , مقايرد وصفة جديدة 2 , مقايرد وصفة جديدة 3', 'mid', 'lunch', '15', '10', '605cb4e9a51a1.jpg', NULL, 9, '30', NULL, 11),
('كيك البيت', 'نضع في الخلاط المكونات التالية بحسب هذا الترتيب: البيض، السكر، الزيت والحليب.\r\nنسكب الخليط في وعاء ونضيف البايكنغ باودر ثم نضيف الطحين تدريجيا مع التحريك.\r\nنسكب خليط الكيك في قالب مدهون بالزبدة ومرشوش بالطحين.\r\nنضع قالب الكيك في الفرن لمدة 40 دقيقة تقريبا على حرارة متوسطة أي 180 درجة، وصحتين وعافية.', '4 بيض\r\n2 كوب طحين\r\n1 1/2 كوب سكر\r\n1 كوب حليب سائل\r\n3/4 كوب زيت\r\n2 ملعقة كبيرة بايكنغ باودر\r\nقشر حامض مبشور حسب الرغبة\r\nفانيلا حسب الرغبة', 'mid', 'Sweetening', '200', '24', NULL, NULL, 10, '40', NULL, 13),
('قهوة', ' وضع ماء ساخن مع القهوة و السكر ', 'ماء , قهوة', 'easy', 'Sidedishes', '200', '24', NULL, '60607295ecd1c.jpg', 11, 'الوقت', NULL, 15),
('قهوة', ' وضع ماء ساخن مع القهوة و السكر ', 'ماء , قهوة', 'easy', 'Sidedishes', '200', '24', NULL, '6060732b31f6d.jpg', 12, 'الوقت', NULL, 15);

-- --------------------------------------------------------

--
-- بنية الجدول `slideshow`
--

CREATE TABLE `slideshow` (
  `name` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `des` text DEFAULT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- إرجاع أو استيراد بيانات الجدول `slideshow`
--

INSERT INTO `slideshow` (`name`, `image`, `des`, `id`) VALUES
('   اهلا بك الى مذاق2222', '60576656ac5f2.jpg', '    تصفحي في موقعنا عن كل الوصفات والاطباق من كل العالم متوفرة بين يديك \r\n', 1),
('منتج واحد', '6057664aa1ccf.jpg', ' منتج واحد منتج واحد منتج واحد', 2);

-- --------------------------------------------------------

--
-- بنية الجدول `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `address` text NOT NULL,
  `phone` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- إرجاع أو استيراد بيانات الجدول `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `type`, `image`, `address`, `phone`) VALUES
(3, 'محمد عبد الله 2', 'user@gmail.com', 'user', NULL, '6057a22026bac.jpg', ' الممكلة السعودية الرياض', '123456'),
(5, 'شمياء احمد', 'admin@gmail.com', 'admin', 'admin', '6057bd984ebc3.jpg', ' الممكلة السعودية الرياض', '123456'),
(6, ' حسام احمد', 'aaa@aaa.com', 'aaa', NULL, '6057c88175bd9.jpg', 'dasdasd adasd', '45645564'),
(7, ' حسام احمد', 'aaa@aaa.com', 'aaa', '', '605b08680912c.png', 'dasdasd adasd', '45645564'),
(8, 'taif al-ghamdi', 'tipyeong6@gmail.com', 'vixxsj15', NULL, NULL, '', ''),
(9, 'esra', 'exvvvz@gmail.com', '1234', NULL, NULL, '', '989097'),
(10, 'ismail', 'ismail', '3mrmosho', NULL, '605c9d349972a.jpg', 'asdasdas asdasd', '78795'),
(11, 'احمد حسن', 'empcland@gmail.com', '3mrmosho', NULL, '605c9d61516af.jpg', 'dasd', 'das'),
(12, 'بتول محمد', 'ba200-@hotmail.com', 'ba200', NULL, NULL, 'كلية المجتمع-دمام', ''),
(13, 'taif', 'tippahae@gmail.com', 'vixxsj15', NULL, NULL, '', ''),
(14, 'taif alghamdi', 'tippahae@gmail.com', 'vixxsj15', NULL, NULL, '', ''),
(15, 'taif', 'tippahae@gmail.com', 'رهءءست15', NULL, NULL, '', ''),
(16, 'taif', '', '', NULL, NULL, '', ''),
(17, 'taif', 'tippahae@gmail.com', 'رهءءست15', NULL, NULL, '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bookmarkes`
--
ALTER TABLE `bookmarkes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cartcheck`
--
ALTER TABLE `cartcheck`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `follow`
--
ALTER TABLE `follow`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `likes`
--
ALTER TABLE `likes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products_categories`
--
ALTER TABLE `products_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `recipes`
--
ALTER TABLE `recipes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `slideshow`
--
ALTER TABLE `slideshow`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bookmarkes`
--
ALTER TABLE `bookmarkes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT for table `cartcheck`
--
ALTER TABLE `cartcheck`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `follow`
--
ALTER TABLE `follow`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `likes`
--
ALTER TABLE `likes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `products_categories`
--
ALTER TABLE `products_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `recipes`
--
ALTER TABLE `recipes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `slideshow`
--
ALTER TABLE `slideshow`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
